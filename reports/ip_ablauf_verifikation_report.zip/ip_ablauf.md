# Seen-DB Expiry Forecast

Lauf: 2026-11-06 12:25 CET (Europe/Berlin)
Gesamt: 11,180,585 IPs in seen_db.json (7,972,586 aktiv/180-Tage-Pfad, 3,207,999 Watchlist/30-Tage-Pfad)

## Aktive IPs (180-Tage-Fenster) – wann faellt die Bestaetigung aus?

| Zeitfenster | Anzahl IPs |
|---|---:|
| bereits ueberfaellig (Cleanup-Pass sollte das entfernen) | 0 |
| 0-7 Tage | 170,316 |
| 8-14 Tage | 291,875 |
| 15-30 Tage | 551,664 |
| 31-60 Tage | 729,599 |
| 61-90 Tage | 898,416 |
| 91-180 Tage | 5,330,716 |

## Watchlist-IPs (30-Tage-Fenster) – wann faellt die Erstsichtung aus?

| Zeitfenster | Anzahl IPs |
|---|---:|
| bereits ueberfaellig | 2,927,557 |
| 0-3 Tage | 42,931 |
| 4-7 Tage | 44,698 |
| 8-14 Tage | 76,986 |
| 15-30 Tage | 115,827 |

## Konkrete Ablauftermine, Watchlist-IPs, naechste 30 Tage

Tagesgenau, im Gegensatz zu den groben Zeitfenstern oben - damit sich der Anti-Churn-Fix (eingefrorene first-Daten bei erneutem Auftauchen, siehe state/watchlist_expired_history.json) konkret nachvollziehen laesst: Faellt die IP-Zahl an einem vorhergesagten Tag tatsaechlich, und bleibt sie danach unten (pruefbar zusaetzlich mit dem Job "verifikation" in dieser Datei, der aktiv auf Rueckkehrer prueft)?

| Datum | Anzahl IPs, die an diesem Tag ihre Erstsichtungs-Frist verlieren |
|---|---:|
| 2026-11-06 | 12,010 |
| 2026-11-07 | 13,295 |
| 2026-11-08 | 6,216 |
| 2026-11-09 | 11,410 |
| 2026-11-10 | 23,581 |
| 2026-11-11 | 9,835 |
| 2026-11-12 | 7,980 |
| 2026-11-13 | 3,302 |
| 2026-11-14 | 11,546 |
| 2026-11-15 | 14,260 |
| 2026-11-16 | 18,804 |
| 2026-11-17 | 9,286 |
| 2026-11-18 | 3,468 |
| 2026-11-19 | 8,771 |
| 2026-11-20 | 10,851 |
| 2026-11-21 | 9,944 |
| 2026-11-22 | 9,991 |
| 2026-11-23 | 10,034 |
| 2026-11-24 | 10,111 |
| 2026-11-25 | 7,621 |
| 2026-11-26 | 3,345 |
| 2026-11-27 | 3,866 |
| 2026-11-28 | 3,550 |
| 2026-11-29 | 8,145 |
| 2026-11-30 | 7,139 |
| 2026-12-01 | 8,089 |
| 2026-12-02 | 4,625 |
| 2026-12-03 | 7,746 |
| 2026-12-04 | 5,781 |
| 2026-12-05 | 5,440 |
| 2026-12-06 | 3,139 |

## Erwartete tatsaechliche Watchlist-Entfernungen (mit Tagesdeckel)

update_combined_blacklist.yml entfernt ueber die 30-Tage-Regel hoechstens **2,000 IPs pro Kalendertag** (FIX WATCHLIST-DAILY-CAP, 31.08.2026). Ueberzaehlige Kandidaten bleiben in seen_db und ruecken nach hinten - es geht nichts verloren, der Abbau wird nur gestreckt. Die rechte Spalte ist deshalb die realistische Erwartung, gegen die der Job "verifikation" prueft.

Bereits ueberfaelliger Rueckstau zu Beginn: **2,927,557** IPs. Brutto faellig in den naechsten 30 Tagen: **273,181**, davon im selben Fenster tatsaechlich entfernbar: **62,000**. Verbleibender Rueckstau am Fensterende: **3,138,738**.

| Datum | Brutto faellig | Erwartet entfernt (mit Deckel) |
|---|---:|---:|
| 2026-11-06 | 12,010 | 2,000 |
| 2026-11-07 | 13,295 | 2,000 |
| 2026-11-08 | 6,216 | 2,000 |
| 2026-11-09 | 11,410 | 2,000 |
| 2026-11-10 | 23,581 | 2,000 |
| 2026-11-11 | 9,835 | 2,000 |
| 2026-11-12 | 7,980 | 2,000 |
| 2026-11-13 | 3,302 | 2,000 |
| 2026-11-14 | 11,546 | 2,000 |
| 2026-11-15 | 14,260 | 2,000 |
| 2026-11-16 | 18,804 | 2,000 |
| 2026-11-17 | 9,286 | 2,000 |
| 2026-11-18 | 3,468 | 2,000 |
| 2026-11-19 | 8,771 | 2,000 |
| 2026-11-20 | 10,851 | 2,000 |
| 2026-11-21 | 9,944 | 2,000 |
| 2026-11-22 | 9,991 | 2,000 |
| 2026-11-23 | 10,034 | 2,000 |
| 2026-11-24 | 10,111 | 2,000 |
| 2026-11-25 | 7,621 | 2,000 |
| 2026-11-26 | 3,345 | 2,000 |
| 2026-11-27 | 3,866 | 2,000 |
| 2026-11-28 | 3,550 | 2,000 |
| 2026-11-29 | 8,145 | 2,000 |
| 2026-11-30 | 7,139 | 2,000 |
| 2026-12-01 | 8,089 | 2,000 |
| 2026-12-02 | 4,625 | 2,000 |
| 2026-12-03 | 7,746 | 2,000 |
| 2026-12-04 | 5,781 | 2,000 |
| 2026-12-05 | 5,440 | 2,000 |
| 2026-12-06 | 3,139 | 2,000 |

> Hinweis: Der Rueckstau von 3,138,738 IPs waechst schneller, als der Tagesdeckel ihn abbauen kann. Bei dauerhaftem Trend WATCHLIST_DAILY_CAP in update_combined_blacklist.yml anheben.

## Konkrete Ablauftermine, aktive IPs, naechste 60 Tage

Zeigt einzelne Tage mit ueberdurchschnittlich vielen gleichzeitig ablaufenden IPs (z.B. durch einen einmaligen Massenimport an einem bestimmten Tag vor 180 Tagen).

| Datum | Anzahl IPs, die an diesem Tag ihre Bestaetigung verlieren |
|---|---:|
| 2026-11-07 | 24,295 |
| 2026-11-08 | 25,973 |
| 2026-11-09 | 25,377 |
| 2026-11-10 | 32,529 |
| 2026-11-11 | 22,212 |
| 2026-11-12 | 20,395 |
| 2026-11-13 | 19,535 |
| 2026-11-14 | 22,825 |
| 2026-11-15 | 17,376 |
| 2026-11-16 | 17,850 |
| 2026-11-17 | 15,156 |
| 2026-11-18 | 19,400 |
| 2026-11-19 | 173,266 |
| 2026-11-20 | 26,002 |
| 2026-11-21 | 61,131 |
| 2026-11-22 | 30,265 |
| 2026-11-23 | 25,524 |
| 2026-11-24 | 26,353 |
| 2026-11-25 | 27,388 |
| 2026-11-26 | 28,552 |
| 2026-11-27 | 27,738 |
| 2026-11-28 | 109,027 |
| 2026-11-29 | 28,081 |
| 2026-11-30 | 25,434 |
| 2026-12-01 | 26,455 |
| 2026-12-02 | 26,092 |
| 2026-12-03 | 25,901 |
| 2026-12-04 | 27,827 |
| 2026-12-05 | 25,867 |
| 2026-12-06 | 30,029 |
| 2026-12-07 | 23,664 |
| 2026-12-08 | 39,265 |
| 2026-12-09 | 54,819 |
| 2026-12-10 | 25,016 |
| 2026-12-11 | 27,684 |
| 2026-12-12 | 24,307 |
| 2026-12-13 | 23,772 |
| 2026-12-14 | 23,389 |
| 2026-12-15 | 26,160 |
| 2026-12-16 | 16,576 |
| 2026-12-17 | 24,947 |
| 2026-12-18 | 22,438 |
| 2026-12-19 | 25,527 |
| 2026-12-20 | 14,270 |
| 2026-12-21 | 27,265 |
| 2026-12-22 | 24,037 |
| 2026-12-23 | 21,070 |
| 2026-12-24 | 20,365 |
| 2026-12-25 | 21,578 |
| 2026-12-26 | 17,782 |
| 2026-12-27 | 24,607 |
| 2026-12-28 | 21,710 |
| 2026-12-29 | 22,539 |
| 2026-12-30 | 26,486 |
| 2026-12-31 | 20,132 |
| 2027-01-01 | 18,493 |
| 2027-01-02 | 26,089 |
| 2027-01-03 | 14,809 |
| 2027-01-04 | 28,432 |
| 2027-01-05 | 22,371 |

## Ledger-Konsistenz (gegen aktuelle seen_db geprüft)

✅ Keine Inkonsistenzen - eingefrorene Active-IP-Adressen bleiben komplett aus seen_db/COMB draussen, solange keine echte starke Neubestätigung (2+ HQ-Familien) den Ledger-Eintrag freigibt.

*Hinweis: Seit dem 21.09.2026 gilt fuer den Active/180T-Pfad ein harter Wiedereintrittsschutz: schwache Evidenz darf keine eingefrorene IP mehr in die COMB/Watchlist zurueckbringen. Erst 2+ unabhaengige HQ-Familien am selben Tag erlauben einen echten Wiedereintritt.*
