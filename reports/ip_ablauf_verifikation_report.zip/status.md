# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 87983 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-10-31 02:17 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -86,938 (Rückgang) (jetzt 11,144,718)
- seit Zyklus-Start (2026-10-22): 📈 +86,275 (Anstieg)
- letzter combined-Cleanup-Pass: 89,983 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 87,983 Active/180T), 866,944 neue IPs hinzugekommen (davon 744,259 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 18 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 119,960 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,968,860 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 216,943 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 6,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 210,943 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-29T22:58 bis 2026-10-31T01:03 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| blacklist_confidence40_ipv4_part1.txt | 63820 | 1.0.149.227, 1.0.211.34, 1.1.140.164, 1.1.230.7, 1.1.251.105, ... |
| blacklist_confidence40_ipv4_part2.txt | 24163 | 222.75.165.169, 222.75.165.215, 222.75.166.209, 222.75.166.223, 222.75.166.233, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
