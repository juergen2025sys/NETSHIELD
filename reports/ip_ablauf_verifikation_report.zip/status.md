# ✅ OK

0 Rückfälle - keine der 922,652 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-27 03:21 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -7,718 (Rückgang) (jetzt 11,765,767)
- seit Zyklus-Start (2026-09-22): 📈 +288,048 (Anstieg)
- letzter combined-Cleanup-Pass: 16,988 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 14,988 Active/180T), 934,756 neue IPs hinzugekommen (davon 804,230 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 31 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 121,414 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,504,537 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 16,988 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 14,988 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-26T12:28 bis 2026-09-27T00:42 UTC
