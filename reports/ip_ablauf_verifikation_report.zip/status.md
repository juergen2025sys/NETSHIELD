# ✅ OK

0 Rückfälle - keine der 4,218,660 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-20 02:14 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +870 (Anstieg) (jetzt 11,265,263)
- seit Zyklus-Start (2026-10-22): 📈 +206,820 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 819,161 neue IPs hinzugekommen (davon 713,141 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 1 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 105,685 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,759,761 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 0 | gestern 175,100 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 0 | gestern 2,000
  - davon Active/180 Tage: heute 0 | gestern 173,100
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-19T02:28 bis 2026-11-20T01:09 UTC
