# ✅ OK

0 Rückfälle - keine der 1,021,536 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-09 21:43 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +5,628 (Anstieg) (jetzt 10,835,343)
- seit Zyklus-Start (2026-08-23): 📈 +1,439,304 (Anstieg)
- letzter combined-Cleanup-Pass: 292,370 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 292,370 Active/180T), 1,129,360 neue IPs hinzugekommen (davon 939,434 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 62 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 188,442 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,057,487 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,341,233 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,339,233 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-09T00:34 bis 2026-09-09T18:46 UTC
