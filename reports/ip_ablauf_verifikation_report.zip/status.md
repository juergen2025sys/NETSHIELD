# ✅ OK

0 Rückfälle - keine der 840,684 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-15 14:23 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +24,458 (Anstieg) (jetzt 11,251,284)
- seit Zyklus-Start (2026-08-23): 📈 +1,855,245 (Anstieg)
- letzter combined-Cleanup-Pass: 244,780 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,780 Active/180T), 1,090,124 neue IPs hinzugekommen (davon 937,272 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 221 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 140,115 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,638,133 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,961,915 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,959,915 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-14T18:10 bis 2026-09-15T12:09 UTC
