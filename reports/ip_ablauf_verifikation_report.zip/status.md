# ✅ OK

0 Rückfälle - keine der 4,305,130 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-21 16:18 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +12,205 (Anstieg) (jetzt 11,248,765)
- seit Zyklus-Start (2026-11-21): 📉 -23,445 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 868,986 neue IPs hinzugekommen (davon 759,231 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 32 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 109,290 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,218,563 (Summe 5 verschiedene Combined-Läufe in den letzten 5 Prüfläufen / 5 Lauf(e), noch keine 24h Historie seit Zyklus-Start; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 63,067 | gestern 27,157 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,178
  - davon Active/180 Tage: heute 61,067 | gestern 25,979
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-11-20T19:58 bis 2026-11-21T12:26 UTC
