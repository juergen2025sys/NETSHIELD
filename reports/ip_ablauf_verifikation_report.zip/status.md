# ✅ OK

0 Rückfälle - keine der 1,001,664 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-04 23:55 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 12,238,086)
- seit Zyklus-Start (2026-09-22): 📈 +760,367 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 883,703 neue IPs hinzugekommen (davon 790,744 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 121 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 91,617 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,209,772 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 14,536 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 12,536 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-10-04T05:40 bis 2026-10-04T21:54 UTC
