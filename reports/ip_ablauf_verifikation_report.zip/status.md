# ✅ OK

0 Rückfälle - keine der 3,652,982 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-02 03:21 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -22,686 (Rückgang) (jetzt 11,156,872)
- seit Zyklus-Start (2026-10-22): 📈 +98,429 (Anstieg)
- letzter combined-Cleanup-Pass: 30,620 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 28,620 Active/180T), 825,367 neue IPs hinzugekommen (davon 696,632 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 50 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 125,269 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,755,370 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 60,301 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 56,301 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-01T00:14 bis 2026-11-02T00:32 UTC
