# ✅ OK

0 Rückfälle - keine der 834,730 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-21 21:47 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +7,531 (Anstieg) (jetzt 11,475,071)
- seit Zyklus-Start (2026-08-23): 📈 +2,079,032 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 954,364 neue IPs hinzugekommen (davon 827,519 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 119 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 126,117 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,224,235 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,217,362 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,215,362 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-20T23:20 bis 2026-09-21T18:49 UTC
