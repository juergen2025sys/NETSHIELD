# ✅ OK

0 Rückfälle - keine der 3,094,394 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-14 19:42 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +7,953 (Anstieg) (jetzt 10,803,827)
- seit Zyklus-Start (2026-09-22): 📉 -673,892 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 899,924 neue IPs hinzugekommen (davon 771,769 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 1,262 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 120,268 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,075,010 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 69,800 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 65,800 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-13T21:31 bis 2026-10-14T17:36 UTC
