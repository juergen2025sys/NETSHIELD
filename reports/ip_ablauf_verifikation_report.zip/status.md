# ✅ OK

0 Rückfälle - keine der 3,828,528 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-08 15:00 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,174 (Anstieg) (jetzt 11,187,895)
- seit Zyklus-Start (2026-10-22): 📈 +129,452 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 812,023 neue IPs hinzugekommen (davon 706,530 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 9 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 109,930 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,058,676 (Summe 5 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 27,967 | gestern 26,291 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 25,967 | gestern 24,291
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-07T12:50 bis 2026-11-08T13:52 UTC
