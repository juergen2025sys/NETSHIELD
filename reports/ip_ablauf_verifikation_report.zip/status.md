# ✅ OK

0 Rückfälle - keine der 197,532 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-30 13:48 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 9,593,508)
- seit Zyklus-Start (2026-08-23): 📈 +197,469 (Anstieg)
- letzter combined-Cleanup-Pass: 171,412 IPs durch Ablauf entfernt (davon 171,412 Watchlist/30T, 0 Active/180T), 1,860,966 neue IPs hinzugekommen (davon 1,639,784 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 43 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 190,907 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,875,092 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,359,666 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 1,359,666 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-08-29T16:49 bis 2026-08-30T11:48 UTC
