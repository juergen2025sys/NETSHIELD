# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 176452 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-09-02 15:36 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,805 (Anstieg) (jetzt 11,107,873)
- seit Zyklus-Start (2026-08-23): 📈 +1,711,834 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 1,021,898 neue IPs hinzugekommen (davon 828,556 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 14 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 194,035 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,593,327 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-01T18:40 bis 2026-09-02T11:44 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| active_blacklist_ipv4.txt | 118 | 101.53.250.20, 103.160.234.194, 103.182.69.27, 103.82.252.62, 104.207.57.110, ... |
| combined_threat_blacklist_ipv4_part1.txt | 83262 | 1.0.137.182, 1.1.176.123, 1.1.197.87, 1.1.221.157, 1.1.245.219, ... |
| combined_threat_blacklist_ipv4_part2.txt | 93190 | 112.135.127.151, 112.135.217.244, 112.135.4.99, 112.135.55.197, 112.135.58.114, ... |
| blacklist_confidence40_ipv4_part1.txt | 118 | 101.53.250.20, 103.160.234.194, 103.182.69.27, 103.82.252.62, 104.207.57.110, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
