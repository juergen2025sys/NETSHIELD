# ✅ OK

0 Rückfälle - keine der 4,385,773 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-25 01:15 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,890 (Anstieg) (jetzt 11,291,247)
- seit Zyklus-Start (2026-11-21): 📈 +19,037 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 908,054 neue IPs hinzugekommen (davon 798,341 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 118 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,726 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,463,552 (Summe 6 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 0 | gestern 28,299 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 0 | gestern 2,000
  - davon Active/180 Tage: heute 0 | gestern 26,299
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-24T02:06 bis 2026-11-25T00:07 UTC
