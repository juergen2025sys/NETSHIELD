# ✅ OK

0 Rückfälle - keine der 4,385,999 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-24 13:24 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +21,316 (Anstieg) (jetzt 11,276,403)
- seit Zyklus-Start (2026-11-21): 📈 +4,193 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 909,103 neue IPs hinzugekommen (davon 795,859 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 522 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 110,558 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,447,491 (Summe 6 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 28,303 | gestern 27,497 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 26,303 | gestern 25,497
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-23T03:29 bis 2026-11-24T10:56 UTC
