# ✅ OK

0 Rückfälle - keine der 4,335,023 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-22 13:10 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,560 (Anstieg) (jetzt 11,259,767)
- seit Zyklus-Start (2026-11-21): 📉 -12,443 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 903,594 neue IPs hinzugekommen (davon 793,540 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 246 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,203 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,186,998 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 32,219 | gestern 62,183 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,117
  - davon Active/180 Tage: heute 30,219 | gestern 61,066
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-21T11:48 bis 2026-11-22T11:59 UTC
