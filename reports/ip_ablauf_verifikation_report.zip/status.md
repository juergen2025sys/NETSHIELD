# ✅ OK

0 Rückfälle - keine der 4,467,721 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-27 20:17 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +43,930 (Anstieg) (jetzt 11,352,628)
- seit Zyklus-Start (2026-11-21): 📈 +80,418 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 980,975 neue IPs hinzugekommen (davon 876,068 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 52 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 8 Whitelist-Bereinigung, 106,683 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,341,535 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 29,692 | gestern 29,420 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 914
  - davon Active/180 Tage: heute 27,692 | gestern 28,506
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-26T17:10 bis 2026-11-27T19:14 UTC
