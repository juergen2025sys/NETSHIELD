# ✅ OK

0 Rückfälle - keine der 4,027,188 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-17 03:05 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -12,130 (Rückgang) (jetzt 11,359,063)
- seit Zyklus-Start (2026-10-22): 📈 +300,620 (Anstieg)
- letzter combined-Cleanup-Pass: 17,141 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 15,141 Active/180T), 822,851 neue IPs hinzugekommen (davon 713,203 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 4 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,251 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,574,404 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 17,141 | gestern 19,007 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,175
  - davon Active/180 Tage: heute 15,141 | gestern 17,832
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-15T22:43 bis 2026-11-17T00:35 UTC
