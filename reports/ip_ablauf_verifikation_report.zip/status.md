# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 2 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-08-30 23:46 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -13,898 (Rückgang) (jetzt 9,586,079)
- seit Zyklus-Start (2026-08-23): 📈 +190,040 (Anstieg)
- letzter combined-Cleanup-Pass: 199,289 IPs durch Ablauf entfernt (davon 199,289 Watchlist/30T, 0 Active/180T), 1,946,774 neue IPs hinzugekommen (davon 1,613,870 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 944 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 190,035 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,853,333 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,399,170 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 1,399,170 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-30T05:12 bis 2026-08-30T21:35 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| active_blacklist_ipv4.txt | 2 | 122.183.40.107, 137.184.125.181 |
| combined_threat_blacklist_ipv4_part2.txt | 2 | 122.183.40.107, 137.184.125.181 |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
