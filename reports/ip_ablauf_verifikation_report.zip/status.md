# ✅ OK

0 Rückfälle - keine der 1,339,050 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-09 17:16 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +4,633 (Anstieg) (jetzt 12,213,457)
- seit Zyklus-Start (2026-09-22): 📈 +735,738 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 917,516 neue IPs hinzugekommen (davon 791,101 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 258 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,084 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,366,019 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 445,250 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 441,250 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-08T13:20 bis 2026-10-09T13:08 UTC
