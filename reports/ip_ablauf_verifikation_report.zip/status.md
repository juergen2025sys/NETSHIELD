# ✅ OK

0 Rückfälle - keine der 836,248 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-17 07:37 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +11,006 (Anstieg) (jetzt 11,366,937)
- seit Zyklus-Start (2026-08-23): 📈 +1,970,898 (Anstieg)
- letzter combined-Cleanup-Pass: 246,232 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 244,232 Active/180T), 1,082,234 neue IPs hinzugekommen (davon 934,893 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 2,976 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 139,708 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,619,487 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,957,078 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,955,078 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-16T12:05 bis 2026-09-17T05:34 UTC
