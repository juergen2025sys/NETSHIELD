# ✅ OK

0 Rückfälle - keine der 4,576,055 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-28 20:58 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +9,095 (Anstieg) (jetzt 11,325,684)
- seit Zyklus-Start (2026-11-21): 📈 +53,474 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 1,024,337 neue IPs hinzugekommen (davon 921,614 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 297 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 105,255 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,897,296 (Summe 6 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 110,935 | gestern 29,691 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 108,935 | gestern 27,691
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-27T16:46 bis 2026-11-28T18:33 UTC
