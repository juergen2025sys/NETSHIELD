# ✅ OK

0 Rückfälle - keine der 1,021,439 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-10 01:42 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +732 (Anstieg) (jetzt 10,837,423)
- seit Zyklus-Start (2026-08-23): 📈 +1,441,384 (Anstieg)
- letzter combined-Cleanup-Pass: 294,228 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 292,228 Active/180T), 1,125,841 neue IPs hinzugekommen (davon 939,182 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 37 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 188,064 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,939,645 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,341,136 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,339,136 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-09T09:43 bis 2026-09-09T23:30 UTC
