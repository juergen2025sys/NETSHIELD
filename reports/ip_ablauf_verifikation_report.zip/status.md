# ✅ OK

0 Rückfälle - keine der 1,020,671 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-11 11:09 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +40,163 (Anstieg) (jetzt 10,975,165)
- seit Zyklus-Start (2026-08-23): 📈 +1,579,126 (Anstieg)
- letzter combined-Cleanup-Pass: 242,475 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 242,475 Active/180T), 1,176,584 neue IPs hinzugekommen (davon 946,264 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 49 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 194,290 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,175,121 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,231,333 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,229,333 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-10T16:41 bis 2026-09-11T06:43 UTC
