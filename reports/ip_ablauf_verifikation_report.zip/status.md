# ✅ OK

0 Rückfälle - keine der 834,716 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-22 01:14 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,204 (Anstieg) (jetzt 11,481,275)
- seit Zyklus-Start (2026-08-23): 📈 +2,085,236 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 960,484 neue IPs hinzugekommen (davon 829,491 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 336 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 125,035 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,008,199 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 731,178 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 729,178 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-21T04:43 bis 2026-09-21T20:48 UTC
