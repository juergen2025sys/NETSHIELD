# ✅ OK

0 Rückfälle - keine der 4,012,447 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-16 08:29 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -7,156 (Rückgang) (jetzt 11,354,240)
- seit Zyklus-Start (2026-10-22): 📈 +295,797 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 831,081 neue IPs hinzugekommen (davon 714,380 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 4,199 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 109,130 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,579,770 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 19,834 | gestern 18,535 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,174
  - davon Active/180 Tage: heute 17,834 | gestern 17,361
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-15T07:12 bis 2026-11-16T07:18 UTC
