# ✅ OK

0 Rückfälle - keine der 4,467,985 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-27 03:11 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -27,906 (Rückgang) (jetzt 11,289,194)
- seit Zyklus-Start (2026-11-21): 📈 +16,984 (Anstieg)
- letzter combined-Cleanup-Pass: 29,695 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 27,695 Active/180T), 904,973 neue IPs hinzugekommen (davon 802,448 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 52 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 103,556 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,350,698 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 29,695 | gestern 29,421 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 914
  - davon Active/180 Tage: heute 27,695 | gestern 28,507
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-26T00:57 bis 2026-11-27T01:50 UTC
