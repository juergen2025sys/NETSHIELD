# ✅ OK

0 Rückfälle - keine der 3,060,057 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-13 11:21 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +14,005 (Anstieg) (jetzt 10,745,406)
- seit Zyklus-Start (2026-09-22): 📉 -732,313 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 860,655 neue IPs hinzugekommen (davon 735,034 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 118 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 123,858 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,165,658 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 3,300,340 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 8,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 3,292,340 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-12T00:43 bis 2026-10-13T06:39 UTC
