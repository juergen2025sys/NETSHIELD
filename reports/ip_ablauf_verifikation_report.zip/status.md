# ✅ OK

0 Rückfälle - keine der 1,019,887 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-12 16:23 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +11,520 (Anstieg) (jetzt 11,055,868)
- seit Zyklus-Start (2026-08-23): 📈 +1,659,829 (Anstieg)
- letzter combined-Cleanup-Pass: 242,463 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 242,463 Active/180T), 1,068,058 neue IPs hinzugekommen (davon 934,014 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 55 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 geschützt entfernt, 136,925 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,370,721 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,965,056 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,963,056 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 13/15 erfolgreich (87%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-11T23:24 bis 2026-09-12T12:56 UTC
