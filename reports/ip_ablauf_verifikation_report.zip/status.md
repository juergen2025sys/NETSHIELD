# ✅ OK

0 Rückfälle - keine der 835,380 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-19 18:11 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,549 (Anstieg) (jetzt 11,546,231)
- seit Zyklus-Start (2026-08-23): 📈 +2,150,192 (Anstieg)
- letzter combined-Cleanup-Pass: 243,674 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,674 Active/180T), 1,073,933 neue IPs hinzugekommen (davon 938,989 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 138 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 131,672 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,606,977 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,950,649 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,950,649 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-18T23:25 bis 2026-09-19T16:04 UTC
