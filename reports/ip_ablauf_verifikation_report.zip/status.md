# ✅ OK

0 Rückfälle - keine der 3,975,538 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-14 11:54 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +17,004 (Anstieg) (jetzt 11,329,277)
- seit Zyklus-Start (2026-10-22): 📈 +270,834 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 823,752 neue IPs hinzugekommen (davon 714,315 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 27 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 107,318 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,572,450 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 24,797 | gestern 20,674 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,154
  - davon Active/180 Tage: heute 22,797 | gestern 19,520
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-13T11:36 bis 2026-11-14T10:44 UTC
