# ✅ OK

0 Rückfälle - keine der 3,854,805 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-09 03:37 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -20,469 (Rückgang) (jetzt 11,178,721)
- seit Zyklus-Start (2026-10-22): 📈 +120,278 (Anstieg)
- letzter combined-Cleanup-Pass: 27,366 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 25,366 Active/180T), 817,234 neue IPs hinzugekommen (davon 705,191 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 23 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 111,422 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,066,127 (Summe 5 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 27,366 | gestern 27,115 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,149
  - davon Active/180 Tage: heute 25,366 | gestern 25,966
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-08T00:23 bis 2026-11-09T01:13 UTC
