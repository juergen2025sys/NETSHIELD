# ✅ OK

0 Rückfälle - keine der 197,523 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-30 19:06 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,274 (Anstieg) (jetzt 9,599,977)
- seit Zyklus-Start (2026-08-23): 📈 +203,938 (Anstieg)
- letzter combined-Cleanup-Pass: 171,411 IPs durch Ablauf entfernt (davon 171,411 Watchlist/30T, 0 Active/180T), 1,800,221 neue IPs hinzugekommen (davon 1,630,102 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 47 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 189,803 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,767,525 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,371,293 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 1,371,293 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-29T23:28 bis 2026-08-30T16:58 UTC
