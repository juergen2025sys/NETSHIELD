# ✅ OK

0 Rückfälle - keine der 360,145 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-05 05:46 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -168,032 (Rückgang) (jetzt 11,028,327)
- seit Zyklus-Start (2026-08-23): 📈 +1,632,288 (Anstieg)
- letzter combined-Cleanup-Pass: 173,663 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 173,663 Active/180T), 1,016,533 neue IPs hinzugekommen (davon 828,366 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 38 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 188,873 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
- entfernte IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
  - davon Watchlist/30 Tage: n/a (7/8 Läufe im Fenster mit Daten)
  - davon Active/180 Tage: n/a (7/8 Läufe im Fenster mit Daten)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-04T11:32 bis 2026-09-05T00:37 UTC
