# ✅ OK

0 Rückfälle - keine der 1,021,938 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-09 00:35 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 10,785,512)
- seit Zyklus-Start (2026-08-23): 📈 +1,389,473 (Anstieg)
- letzter combined-Cleanup-Pass: 292,274 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 292,274 Active/180T), 1,134,112 neue IPs hinzugekommen (davon 939,866 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 57 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 191,495 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,215,727 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,339,473 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,339,473 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-08T09:57 bis 2026-09-08T21:25 UTC
