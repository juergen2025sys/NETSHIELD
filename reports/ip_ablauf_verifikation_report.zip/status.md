# ✅ OK

0 Rückfälle - keine der 4,360,272 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-23 03:06 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -16,989 (Rückgang) (jetzt 11,252,183)
- seit Zyklus-Start (2026-11-21): 📉 -20,027 (Rückgang)
- letzter combined-Cleanup-Pass: 27,499 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 25,499 Active/180T), 907,324 neue IPs hinzugekommen (davon 788,477 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 611 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 109,043 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,326,803 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 27,499 | gestern 32,214 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 25,499 | gestern 30,214
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-22T01:36 bis 2026-11-23T01:58 UTC
