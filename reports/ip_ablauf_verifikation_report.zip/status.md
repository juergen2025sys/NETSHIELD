# ✅ OK

0 Rückfälle - keine der 1,339,269 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-09 10:01 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +12,644 (Anstieg) (jetzt 12,191,771)
- seit Zyklus-Start (2026-09-22): 📈 +714,052 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 928,944 neue IPs hinzugekommen (davon 791,477 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 3,311 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 125,132 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,351,661 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 445,250 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 441,250 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-08T06:46 bis 2026-10-09T06:00 UTC
