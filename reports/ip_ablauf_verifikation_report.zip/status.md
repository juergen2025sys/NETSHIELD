# ✅ OK

0 Rückfälle - keine der 3,713,651 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-04 15:22 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,172,266)
- seit Zyklus-Start (2026-10-22): 📈 +113,823 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 815,649 neue IPs hinzugekommen (davon 702,936 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 262 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,978 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,557,319 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 31,403 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 29,403 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-03T11:21 bis 2026-11-04T14:18 UTC
