# ✅ OK

0 Rückfälle - keine der 4,218,763 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-19 19:39 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +4,099 (Anstieg) (jetzt 11,258,907)
- seit Zyklus-Start (2026-10-22): 📈 +200,464 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 822,859 neue IPs hinzugekommen (davon 712,906 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 117 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 106,389 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,945,577 (Summe 6 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 175,103 | gestern 21,377 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 173,103 | gestern 19,377
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-18T20:22 bis 2026-11-19T18:34 UTC
