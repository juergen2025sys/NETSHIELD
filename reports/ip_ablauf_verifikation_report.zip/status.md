# ✅ OK

0 Rückfälle - keine der 360,113 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-06 20:09 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -1,451 (Rückgang) (jetzt 11,128,881)
- seit Zyklus-Start (2026-08-23): 📈 +1,732,842 (Anstieg)
- letzter combined-Cleanup-Pass: 155,409 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,409 Active/180T), 1,026,332 neue IPs hinzugekommen (davon 844,206 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 187,838 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,078,220 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,243,754 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,243,754 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-05T21:31 bis 2026-09-06T15:48 UTC
