# ✅ OK

0 Rückfälle - keine der 186,486 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-04 01:43 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -779 (Rückgang) (jetzt 11,165,432)
- seit Zyklus-Start (2026-08-23): 📈 +1,769,393 (Anstieg)
- letzter combined-Cleanup-Pass: 2,000 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 0 Active/180T), 1,019,574 neue IPs hinzugekommen (davon 829,738 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 10 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 193,039 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,060,717 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-03T09:44 bis 2026-09-03T23:31 UTC
