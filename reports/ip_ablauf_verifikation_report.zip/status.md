# ✅ OK

0 Rückfälle - keine der 3,290,168 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-22 19:46 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +13,445 (Anstieg) (jetzt 11,103,364)
- seit Zyklus-Start (2026-10-22): 📈 +44,921 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 888,225 neue IPs hinzugekommen (davon 762,468 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 346 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 121,560 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,461,019 (Summe letzte 5 Läufe / 5 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- entfernte IPs (Summe letzter Läufe): 32,437 (Summe letzte 5 Läufe / 5 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 5 Läufe / 5 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Active/180 Tage: 30,437 (Summe letzte 5 Läufe / 5 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-21T21:51 bis 2026-10-22T17:38 UTC
