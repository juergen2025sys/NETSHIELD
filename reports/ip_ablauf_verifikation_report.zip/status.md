# ✅ OK

0 Rückfälle - keine der 3,253,453 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-20 02:51 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +506 (Anstieg) (jetzt 10,962,014)
- seit Zyklus-Start (2026-09-22): 📉 -515,705 (Rückgang)
- letzter combined-Cleanup-Pass: 13,053 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 11,053 Active/180T), 893,340 neue IPs hinzugekommen (davon 766,158 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 155 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,419 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,132,670 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 13,053 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 11,053 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-19T05:01 bis 2026-10-20T00:40 UTC
