# ✅ OK

0 Rückfälle - keine der 4,576,142 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-28 12:39 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +18,177 (Anstieg) (jetzt 11,316,589)
- seit Zyklus-Start (2026-11-21): 📈 +44,379 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 1,026,504 neue IPs hinzugekommen (davon 920,357 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 58 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 107,061 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,681,931 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 110,936 | gestern 29,692 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 108,936 | gestern 27,692
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-27T09:06 bis 2026-11-28T09:34 UTC
