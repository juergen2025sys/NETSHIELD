# ✅ OK

0 Rückfälle - keine der 4,412,753 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-25 20:40 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,180 (Anstieg) (jetzt 11,292,015)
- seit Zyklus-Start (2026-11-21): 📈 +19,805 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 908,547 neue IPs hinzugekommen (davon 800,576 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 235 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 107,173 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,280,997 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 29,323 | gestern 28,297 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 27,323 | gestern 26,297
- Erfolgsquote letzte 16 combined-Läufe: 14/15 erfolgreich (93%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-24T23:50 bis 2026-11-25T19:35 UTC
