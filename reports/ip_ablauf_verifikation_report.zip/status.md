# ✅ OK

0 Rückfälle - keine der 933,991 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-28 13:59 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +19,155 (Anstieg) (jetzt 11,827,769)
- seit Zyklus-Start (2026-09-22): 📈 +350,050 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 924,710 neue IPs hinzugekommen (davon 793,986 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 9 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 125,406 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,409,587 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 13,588 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 11,588 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-27T16:52 bis 2026-09-28T09:02 UTC
