# ✅ OK

0 Rückfälle - keine der 4,412,877 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-25 10:25 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,947 (Anstieg) (jetzt 11,279,296)
- seit Zyklus-Start (2026-11-21): 📈 +7,086 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 909,561 neue IPs hinzugekommen (davon 799,976 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 278 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 109,021 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,374,106 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 29,323 | gestern 28,298 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 27,323 | gestern 26,298
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-24T10:56 bis 2026-11-25T09:11 UTC
