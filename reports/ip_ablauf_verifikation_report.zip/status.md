# ✅ OK

0 Rückfälle - keine der 3,975,485 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-14 19:37 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,219 (Anstieg) (jetzt 11,336,028)
- seit Zyklus-Start (2026-10-22): 📈 +277,585 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 822,162 neue IPs hinzugekommen (davon 715,216 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 182 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 105,830 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,746,709 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 24,797 | gestern 20,674 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,154
  - davon Active/180 Tage: heute 22,797 | gestern 19,520
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-13T20:03 bis 2026-11-14T18:29 UTC
