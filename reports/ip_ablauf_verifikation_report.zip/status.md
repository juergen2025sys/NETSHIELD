# ✅ OK

0 Rückfälle - keine der 835,704 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-18 21:34 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +10,041 (Anstieg) (jetzt 11,483,918)
- seit Zyklus-Start (2026-08-23): 📈 +2,087,879 (Anstieg)
- letzter combined-Cleanup-Pass: 243,969 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,969 Active/180T), 1,061,568 neue IPs hinzugekommen (davon 920,954 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 61 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 2 Whitelist-Bereinigung, 130,763 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,554,217 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,954,367 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,952,367 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-18T04:56 bis 2026-09-18T18:49 UTC
