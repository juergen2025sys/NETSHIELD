# ✅ OK

0 Rückfälle - keine der 841,046 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-22 03:50 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,477,719)
- seit Zyklus-Start (2026-09-22): ➡️ unverändert
- letzter combined-Cleanup-Pass: 8,430 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 6,430 Active/180T), 962,643 neue IPs hinzugekommen (davon 829,320 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 94 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 128,694 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 1,925,286 (Summe letzte 2 Läufe / 2 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- entfernte IPs (Summe letzter Läufe): 16,860 (Summe letzte 2 Läufe / 2 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 2 Läufe / 2 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Active/180 Tage: 12,860 (Summe letzte 2 Läufe / 2 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-21T05:30 bis 2026-09-22T00:17 UTC
