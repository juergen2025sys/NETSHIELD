# ✅ OK

0 Rückfälle - keine der 834,870 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-21 03:34 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +4,957 (Anstieg) (jetzt 11,627,828)
- seit Zyklus-Start (2026-08-23): 📈 +2,231,789 (Anstieg)
- letzter combined-Cleanup-Pass: 245,054 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 243,054 Active/180T), 1,076,076 neue IPs hinzugekommen (davon 937,341 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 53 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 132,043 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,568,806 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,946,819 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,944,819 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-20T11:39 bis 2026-09-21T00:37 UTC
