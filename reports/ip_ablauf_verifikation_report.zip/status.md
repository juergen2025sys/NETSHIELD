# ✅ OK

0 Rückfälle - keine der 3,854,570 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-09 13:23 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +8,371 (Anstieg) (jetzt 11,209,981)
- seit Zyklus-Start (2026-10-22): 📈 +151,538 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 817,834 neue IPs hinzugekommen (davon 707,847 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 5 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 109,014 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,892,241 (Summe 6 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 27,364 | gestern 27,112 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,149
  - davon Active/180 Tage: heute 25,364 | gestern 25,963
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-08T09:54 bis 2026-11-09T12:09 UTC
