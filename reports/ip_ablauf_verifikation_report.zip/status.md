# ✅ OK

0 Rückfälle - keine der 3,060,103 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-13 03:38 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -1,571,900 (Rückgang) (jetzt 10,731,401)
- seit Zyklus-Start (2026-09-22): 📉 -746,318 (Rückgang)
- letzter combined-Cleanup-Pass: 1,581,691 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 1,579,691 Active/180T), 899,953 neue IPs hinzugekommen (davon 767,851 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 47 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 124,120 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,194,418 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,718,649 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 6,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,712,649 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-11T22:10 bis 2026-10-13T00:58 UTC
