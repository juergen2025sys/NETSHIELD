# ✅ OK

0 Rückfälle - keine der 890,529 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-25 07:40 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +15,175 (Anstieg) (jetzt 11,656,140)
- seit Zyklus-Start (2026-09-22): 📈 +178,421 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 967,920 neue IPs hinzugekommen (davon 828,535 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 4,357 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 126,407 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,658,157 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 22,902 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 20,902 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-24T12:13 bis 2026-09-25T05:25 UTC
