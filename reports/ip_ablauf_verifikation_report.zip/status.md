# ✅ OK

0 Rückfälle - keine der 3,652,719 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-02 20:54 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +22,467 (Anstieg) (jetzt 11,191,587)
- seit Zyklus-Start (2026-10-22): 📈 +133,144 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 824,086 neue IPs hinzugekommen (davon 699,595 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 27 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 120,533 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,636,085 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 30,620 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 28,620 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-01T16:24 bis 2026-11-02T19:47 UTC
