# ✅ OK

0 Rückfälle - keine der 183,247 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-29 20:19 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +1,925 (Anstieg) (jetzt 9,535,319)
- seit Zyklus-Start (2026-08-23): 📈 +139,280 (Anstieg)
- letzter combined-Cleanup-Pass: 162,296 IPs durch Ablauf entfernt (davon 162,296 Watchlist/30T, 0 Active/180T), 1,857,199 neue IPs hinzugekommen (davon 1,683,452 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 30 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 191,005 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,898,128 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 995,868 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 995,868 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-28T18:17 bis 2026-08-29T16:49 UTC
