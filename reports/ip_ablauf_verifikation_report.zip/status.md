# ✅ OK

0 Rückfälle - keine der 1,022,098 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-08 18:57 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 10,762,899)
- seit Zyklus-Start (2026-08-23): 📈 +1,366,860 (Anstieg)
- letzter combined-Cleanup-Pass: 292,307 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 292,307 Active/180T), 1,142,437 neue IPs hinzugekommen (davon 946,117 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 716 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 191,130 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,909,710 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,928,968 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,928,968 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-07T23:46 bis 2026-09-08T16:50 UTC
