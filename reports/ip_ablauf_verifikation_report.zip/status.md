# ✅ OK

0 Rückfälle - keine der 4,244,538 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-20 10:09 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +10,136 (Anstieg) (jetzt 11,253,080)
- seit Zyklus-Start (2026-10-22): 📈 +194,637 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 830,460 neue IPs hinzugekommen (davon 713,837 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 4,162 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 109,225 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,594,379 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 27,980 | gestern 175,099 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 25,980 | gestern 173,099
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-19T09:34 bis 2026-11-20T08:32 UTC
