# ✅ OK

0 Rückfälle - keine der 360,119 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-06 01:28 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,101,732)
- seit Zyklus-Start (2026-08-23): 📈 +1,705,693 (Anstieg)
- letzter combined-Cleanup-Pass: 155,511 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,511 Active/180T), 977,818 neue IPs hinzugekommen (davon 795,083 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 186,313 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,044,998 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,243,926 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,243,926 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-05T10:55 bis 2026-09-05T23:20 UTC
