# ✅ OK

0 Rückfälle - keine der 836,524 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-16 14:20 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +9,730 (Anstieg) (jetzt 11,326,947)
- seit Zyklus-Start (2026-08-23): 📈 +1,930,908 (Anstieg)
- letzter combined-Cleanup-Pass: 244,632 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,632 Active/180T), 1,082,498 neue IPs hinzugekommen (davon 934,855 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 34 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 138,220 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,533,924 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,958,894 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,956,894 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-15T17:10 bis 2026-09-16T12:05 UTC
