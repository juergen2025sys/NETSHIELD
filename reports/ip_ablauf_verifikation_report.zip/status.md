# ✅ OK

0 Rückfälle - keine der 4,305,205 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-21 07:59 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +15,056 (Anstieg) (jetzt 11,228,674)
- seit Zyklus-Start (2026-11-21): 📉 -43,536 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 853,543 neue IPs hinzugekommen (davon 727,669 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 9,687 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 112,220 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 2,504,074 (Summe 3 verschiedene Combined-Läufe in den letzten 3 Prüfläufen / 3 Lauf(e), noch keine 24h Historie seit Zyklus-Start; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 63,067 | gestern 27,157 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,178
  - davon Active/180 Tage: heute 61,067 | gestern 25,979
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-20T11:58 bis 2026-11-21T06:30 UTC
