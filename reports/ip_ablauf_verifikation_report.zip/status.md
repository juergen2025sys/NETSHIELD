# ❌ ALARM

**1 Problem(e) erkannt:**

- ⚠️ **Niedrige combined-Erfolgsquote:** nur 10/16 erfolgreich (62%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-23T18:58 bis 2026-08-24T02:39 UTC in den letzten 16 Läufen (Schwelle: 75%, cancelled nicht mitgezaehlt) - auch wenn der neueste Stand frisch wirkt, lief das System zuletzt nicht zuverlässig.

Lauf: 2026-08-24 05:12 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 9,416,186)
- seit Zyklus-Start (2026-08-23): 📈 +20,147 (Anstieg)
- letzter combined-Cleanup-Pass: 657,372 IPs durch Ablauf entfernt (davon 657,372 Watchlist/30T, 0 Active/180T), 1,861,175 neue IPs hinzugekommen (davon 1,668,819 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 187,076 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): n/a (6/8 Läufe im Fenster mit Daten)
- entfernte IPs (Summe letzter Läufe): n/a (6/8 Läufe im Fenster mit Daten)
  - davon Watchlist/30 Tage: n/a (5/8 Läufe im Fenster mit Daten)
  - davon Active/180 Tage: n/a (5/8 Läufe im Fenster mit Daten)
- Erfolgsquote letzte 16 combined-Läufe: 🔍 10/16 erfolgreich (62%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-23T18:58 bis 2026-08-24T02:39 UTC

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
