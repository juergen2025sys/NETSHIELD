# ✅ OK

0 Rückfälle - keine der 890,394 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-25 21:33 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +9,439 (Anstieg) (jetzt 11,694,193)
- seit Zyklus-Start (2026-09-22): 📈 +216,474 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 957,717 neue IPs hinzugekommen (davon 828,202 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 149 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 120,272 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,663,591 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 22,902 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 20,902 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-24T21:38 bis 2026-09-25T18:50 UTC
