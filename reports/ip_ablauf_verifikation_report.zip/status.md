# ✅ OK

0 Rückfälle - keine der 4,219,002 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-19 03:54 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,233,056)
- seit Zyklus-Start (2026-10-22): 📈 +174,613 (Anstieg)
- letzter combined-Cleanup-Pass: 175,106 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 173,106 Active/180T), 824,857 neue IPs hinzugekommen (davon 712,001 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 372 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 106,008 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,950,481 (Summe 6 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 175,106 | gestern 21,379 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 173,106 | gestern 19,379
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-18T07:37 bis 2026-11-19T02:49 UTC
