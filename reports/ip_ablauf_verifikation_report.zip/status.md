# ✅ OK

0 Rückfälle - keine der 922,512 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-27 14:37 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +13,270 (Anstieg) (jetzt 11,785,856)
- seit Zyklus-Start (2026-09-22): 📈 +308,137 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 937,504 neue IPs hinzugekommen (davon 808,007 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 240 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,912 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,480,145 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 16,988 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 14,988 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-26T19:29 bis 2026-09-27T12:28 UTC
