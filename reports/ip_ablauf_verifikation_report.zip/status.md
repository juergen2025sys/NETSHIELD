# ✅ OK

0 Rückfälle - keine der 207,353 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-01 06:06 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 9,796,731)
- seit Zyklus-Start (2026-08-23): 📈 +400,692 (Anstieg)
- letzter combined-Cleanup-Pass: 2,000 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 0 Active/180T), 1,802,404 neue IPs hinzugekommen (davon 1,635,618 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 19 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 188,506 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,365,439 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 533,801 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 533,801 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 14/14 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 2 cancelled (nicht gewertet), Zeitraum 2026-08-31T12:34 bis 2026-09-01T00:47 UTC
