# ✅ OK

0 Rückfälle - keine der 183,269 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-29 13:26 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +8,019 (Anstieg) (jetzt 9,525,863)
- seit Zyklus-Start (2026-08-23): 📈 +129,824 (Anstieg)
- letzter combined-Cleanup-Pass: 162,314 IPs durch Ablauf entfernt (davon 162,314 Watchlist/30T, 0 Active/180T), 1,861,625 neue IPs hinzugekommen (davon 1,687,192 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 1 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 192,369 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
- entfernte IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
  - davon Watchlist/30 Tage: n/a (7/8 Läufe im Fenster mit Daten)
  - davon Active/180 Tage: n/a (7/8 Läufe im Fenster mit Daten)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-28T13:16 bis 2026-08-29T10:16 UTC
