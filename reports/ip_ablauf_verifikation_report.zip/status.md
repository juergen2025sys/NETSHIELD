# ✅ OK

0 Rückfälle - keine der 3,951,731 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-13 23:52 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,792 (Anstieg) (jetzt 11,334,522)
- seit Zyklus-Start (2026-10-22): 📈 +276,079 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 819,277 neue IPs hinzugekommen (davon 711,032 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 25 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 105,543 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,752,915 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 21,521 | gestern 22,374 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 19,521 | gestern 20,374
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-13T01:45 bis 2026-11-13T21:41 UTC
