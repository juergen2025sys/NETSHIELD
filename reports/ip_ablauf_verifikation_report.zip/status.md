# ✅ OK

0 Rückfälle - keine der 4,218,673 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-19 22:06 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +5,486 (Anstieg) (jetzt 11,264,393)
- seit Zyklus-Start (2026-10-22): 📈 +205,950 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 821,102 neue IPs hinzugekommen (davon 713,206 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 25 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 105,859 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,940,600 (Summe 6 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 175,100 | gestern 21,377 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 173,100 | gestern 19,377
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-18T21:36 bis 2026-11-19T20:59 UTC
