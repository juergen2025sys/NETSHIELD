# ✅ OK

0 Rückfälle - keine der 3,951,963 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-13 09:45 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +11,811 (Anstieg) (jetzt 11,305,931)
- seit Zyklus-Start (2026-10-22): 📈 +247,488 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 824,929 neue IPs hinzugekommen (davon 711,441 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 13 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 109,892 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,107,452 (Summe 5 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 21,522 | gestern 22,376 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 19,522 | gestern 20,376
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-12T11:36 bis 2026-11-13T07:23 UTC
