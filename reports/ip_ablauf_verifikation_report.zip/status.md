# ✅ OK

0 Rückfälle - keine der 3,739,524 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-05 17:56 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +9,154 (Anstieg) (jetzt 11,181,445)
- seit Zyklus-Start (2026-10-22): 📈 +123,002 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 804,671 neue IPs hinzugekommen (davon 698,080 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 1 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 107,698 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,483,754 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 54,174 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 50,174 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-04T14:18 bis 2026-11-05T16:35 UTC
