# ✅ OK

0 Rückfälle - keine der 907,592 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-26 03:30 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -8,766 (Rückgang) (jetzt 11,687,860)
- seit Zyklus-Start (2026-09-22): 📈 +210,141 (Anstieg)
- letzter combined-Cleanup-Pass: 19,408 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 17,408 Active/180T), 960,220 neue IPs hinzugekommen (davon 827,173 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 101 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,601 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,635,485 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 19,408 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 17,408 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-25T05:09 bis 2026-09-26T00:27 UTC
