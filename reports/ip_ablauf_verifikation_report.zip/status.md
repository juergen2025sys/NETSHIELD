# ✅ OK

0 Rückfälle - keine der 183,291 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-29 09:34 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,880 (Anstieg) (jetzt 9,517,844)
- seit Zyklus-Start (2026-08-23): 📈 +121,805 (Anstieg)
- letzter combined-Cleanup-Pass: 162,347 IPs durch Ablauf entfernt (davon 162,347 Watchlist/30T, 0 Active/180T), 1,862,169 neue IPs hinzugekommen (davon 1,684,942 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 81 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 192,540 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
- entfernte IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
  - davon Watchlist/30 Tage: n/a (7/8 Läufe im Fenster mit Daten)
  - davon Active/180 Tage: n/a (7/8 Läufe im Fenster mit Daten)
- Erfolgsquote letzte 16 combined-Läufe: 14/14 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet) | 1 sonstige, Zeitraum 2026-08-28T04:06 bis 2026-08-29T07:24 UTC
