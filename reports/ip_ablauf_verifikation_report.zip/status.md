# ✅ OK

0 Rückfälle - keine der 1,020,237 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-12 07:17 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +11,161 (Anstieg) (jetzt 11,021,303)
- seit Zyklus-Start (2026-08-23): 📈 +1,625,264 (Anstieg)
- letzter combined-Cleanup-Pass: 245,468 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 245,468 Active/180T), 1,085,587 neue IPs hinzugekommen (davon 945,125 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 6,300 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 geschützt entfernt, 135,459 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,604,590 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,966,006 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,964,006 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-11T16:21 bis 2026-09-12T05:06 UTC
