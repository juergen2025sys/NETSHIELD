# ✅ OK

0 Rückfälle - keine der 4,046,291 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-18 02:27 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -15,310 (Rückgang) (jetzt 11,370,319)
- seit Zyklus-Start (2026-10-22): 📈 +311,876 (Anstieg)
- letzter combined-Cleanup-Pass: 21,382 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 19,382 Active/180T), 823,371 neue IPs hinzugekommen (davon 713,958 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 10 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,562 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,606,131 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 21,382 | gestern 17,141 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 19,382 | gestern 15,141
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-16T19:52 bis 2026-11-18T01:19 UTC
