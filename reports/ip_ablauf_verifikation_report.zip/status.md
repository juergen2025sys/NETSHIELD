# ✅ OK

0 Rückfälle - keine der 933,932 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-28 16:46 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,118 (Anstieg) (jetzt 11,830,887)
- seit Zyklus-Start (2026-09-22): 📈 +353,168 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 921,841 neue IPs hinzugekommen (davon 794,422 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 122 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 124,676 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,394,191 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 13,588 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 11,588 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-27T17:22 bis 2026-09-28T14:30 UTC
