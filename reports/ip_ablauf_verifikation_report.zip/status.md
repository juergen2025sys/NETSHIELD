# ✅ OK

0 Rückfälle - keine der 1,020,709 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-11 06:29 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +19,126 (Anstieg) (jetzt 10,925,392)
- seit Zyklus-Start (2026-08-23): 📈 +1,529,353 (Anstieg)
- letzter combined-Cleanup-Pass: 276,661 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 274,661 Active/180T), 1,153,351 neue IPs hinzugekommen (davon 940,624 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 20 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 195,735 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,126,384 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,297,470 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,295,470 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-10T11:50 bis 2026-09-11T04:26 UTC
