# ✅ OK

0 Rückfälle - keine der 890,388 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-25 23:55 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,433 (Anstieg) (jetzt 11,696,626)
- seit Zyklus-Start (2026-09-22): 📈 +218,907 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 951,535 neue IPs hinzugekommen (davon 829,407 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 261 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 119,891 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,659,413 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 22,902 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 20,902 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-25T04:44 bis 2026-09-25T21:49 UTC
