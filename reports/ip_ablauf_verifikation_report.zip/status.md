# ✅ OK

0 Rückfälle - keine der 907,465 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-26 13:59 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +27,254 (Anstieg) (jetzt 11,724,771)
- seit Zyklus-Start (2026-09-22): 📈 +247,052 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 949,916 neue IPs hinzugekommen (davon 828,758 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 317 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 Whitelist-Bereinigung, 120,623 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,636,429 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 19,408 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 17,408 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-25T18:50 bis 2026-09-26T11:49 UTC
