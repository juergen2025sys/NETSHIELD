# ✅ OK

0 Rückfälle - keine der 1,001,915 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-04 08:33 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,324 (Anstieg) (jetzt 12,170,290)
- seit Zyklus-Start (2026-09-22): 📈 +692,571 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 905,732 neue IPs hinzugekommen (davon 791,458 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 428 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 112,335 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,268,248 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 14,536 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 12,536 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-10-03T14:46 bis 2026-10-04T06:22 UTC
