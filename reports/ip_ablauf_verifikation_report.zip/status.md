# ✅ OK

0 Rückfälle - keine der 1,001,672 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-04 20:23 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +32,694 (Anstieg) (jetzt 12,236,371)
- seit Zyklus-Start (2026-09-22): 📈 +758,652 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 899,887 neue IPs hinzugekommen (davon 788,803 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 54 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 110,858 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,243,964 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 14,536 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 12,536 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-03T21:35 bis 2026-10-04T17:10 UTC
