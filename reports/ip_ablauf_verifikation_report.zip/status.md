# ✅ OK

0 Rückfälle - keine der 3,776,392 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-06 20:46 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,152 (Anstieg) (jetzt 11,192,348)
- seit Zyklus-Start (2026-10-22): 📈 +133,905 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 807,330 neue IPs hinzugekommen (davon 699,985 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 8 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,232 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,496,335 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 38,119 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 36,119 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-05T20:09 bis 2026-11-06T19:42 UTC
