# ✅ OK

0 Rückfälle - keine der 1,010,905 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-14 07:35 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +9,569 (Anstieg) (jetzt 11,116,435)
- seit Zyklus-Start (2026-08-23): 📈 +1,720,396 (Anstieg)
- letzter combined-Cleanup-Pass: 245,397 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 245,397 Active/180T), 1,084,454 neue IPs hinzugekommen (davon 938,628 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 4,241 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 geschützt entfernt, 139,912 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,594,091 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,961,975 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,959,975 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-13T16:01 bis 2026-09-14T05:27 UTC
