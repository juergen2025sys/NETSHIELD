# ✅ OK

0 Rückfälle - keine der 3,931,889 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-12 04:49 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,256,860)
- seit Zyklus-Start (2026-10-22): 📈 +198,417 (Anstieg)
- letzter combined-Cleanup-Pass: 22,377 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 20,377 Active/180T), 817,804 neue IPs hinzugekommen (davon 716,199 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 14 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 107,010 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,724,843 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 22,377 | gestern 23,340 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,158
  - davon Active/180 Tage: heute 20,377 | gestern 22,182
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-11T00:28 bis 2026-11-12T03:45 UTC
