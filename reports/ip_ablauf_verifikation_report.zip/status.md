# ✅ OK

0 Rückfälle - keine der 3,094,515 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-14 03:09 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 10,769,450)
- seit Zyklus-Start (2026-09-22): 📉 -708,269 (Rückgang)
- letzter combined-Cleanup-Pass: 34,900 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 32,900 Active/180T), 869,397 neue IPs hinzugekommen (davon 733,350 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 18 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 125,213 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,083,638 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 3,233,182 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 8,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 3,225,182 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-12T21:20 bis 2026-10-14T00:37 UTC
