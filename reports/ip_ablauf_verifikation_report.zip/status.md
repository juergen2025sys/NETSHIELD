# ✅ OK

0 Rückfälle - keine der 4,412,691 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-26 01:16 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +4,973 (Anstieg) (jetzt 11,296,988)
- seit Zyklus-Start (2026-11-21): 📈 +24,778 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 906,979 neue IPs hinzugekommen (davon 801,047 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 127 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 105,078 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,278,873 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 0 | gestern 29,323 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 0 | gestern 2,000
  - davon Active/180 Tage: heute 0 | gestern 27,323
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-24T23:58 bis 2026-11-25T22:16 UTC
