# ✅ OK

0 Rückfälle - keine der 840,951 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-22 09:41 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,060 (Anstieg) (jetzt 11,495,942)
- seit Zyklus-Start (2026-09-22): 📈 +18,223 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 958,230 neue IPs hinzugekommen (davon 828,390 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 222 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 128,021 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 3,852,967 (Summe letzte 4 Läufe / 4 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- entfernte IPs (Summe letzter Läufe): 16,860 (Summe letzte 4 Läufe / 4 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 4 Läufe / 4 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Active/180 Tage: 12,860 (Summe letzte 4 Läufe / 4 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-21T13:05 bis 2026-09-22T05:37 UTC
