# ✅ OK

0 Rückfälle - keine der 197,527 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-30 17:21 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +4,195 (Anstieg) (jetzt 9,597,703)
- seit Zyklus-Start (2026-08-23): 📈 +201,664 (Anstieg)
- letzter combined-Cleanup-Pass: 171,410 IPs durch Ablauf entfernt (davon 171,410 Watchlist/30T, 0 Active/180T), 1,801,508 neue IPs hinzugekommen (davon 1,629,618 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 24 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 189,656 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,826,047 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,371,707 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 1,371,707 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-29T20:50 bis 2026-08-30T13:09 UTC
