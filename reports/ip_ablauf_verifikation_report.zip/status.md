# ✅ OK

0 Rückfälle - keine der 3,776,507 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-06 12:28 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +20,190 (Anstieg) (jetzt 11,180,585)
- seit Zyklus-Start (2026-10-22): 📈 +122,142 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 820,517 neue IPs hinzugekommen (davon 704,769 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 52 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 110,183 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,482,943 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 65,206 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 61,206 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-05T11:32 bis 2026-11-06T11:15 UTC
