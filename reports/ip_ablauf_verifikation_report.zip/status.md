# ✅ OK

0 Rückfälle - keine der 360,099 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-07 17:07 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,190,798)
- seit Zyklus-Start (2026-08-23): 📈 +1,794,759 (Anstieg)
- letzter combined-Cleanup-Pass: 155,446 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,446 Active/180T), 1,024,025 neue IPs hinzugekommen (davon 831,491 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 639 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 190,022 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,050,445 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,245,307 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,243,307 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-06T20:19 bis 2026-09-07T13:01 UTC
