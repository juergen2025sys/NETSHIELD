# ✅ OK

0 Rückfälle - keine der 840,831 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-22 15:24 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,278 (Anstieg) (jetzt 11,516,051)
- seit Zyklus-Start (2026-09-22): 📈 +38,332 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 958,831 neue IPs hinzugekommen (davon 828,952 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 124 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 126,841 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,774,704 (Summe letzte 6 Läufe / 6 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- entfernte IPs (Summe letzter Läufe): 16,860 (Summe letzte 6 Läufe / 6 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 6 Läufe / 6 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Active/180 Tage: 12,860 (Summe letzte 6 Läufe / 6 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-21T19:56 bis 2026-09-22T12:03 UTC
