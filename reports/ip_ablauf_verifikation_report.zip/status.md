# ✅ OK

0 Rückfälle - keine der 4,440,605 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-27 01:12 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +5,931 (Anstieg) (jetzt 11,317,100)
- seit Zyklus-Start (2026-11-21): 📈 +44,890 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 903,999 neue IPs hinzugekommen (davon 801,873 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 46 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 103,910 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,358,739 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 0 | gestern 30,506 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 0 | gestern 1,999
  - davon Active/180 Tage: heute 0 | gestern 28,507
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-25T22:16 bis 2026-11-27T00:00 UTC
