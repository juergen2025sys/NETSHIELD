# ✅ OK

0 Rückfälle - keine der 1,021,346 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-10 07:28 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +12,700 (Anstieg) (jetzt 10,850,123)
- seit Zyklus-Start (2026-08-23): 📈 +1,454,084 (Anstieg)
- letzter combined-Cleanup-Pass: 291,681 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 291,681 Active/180T), 1,135,873 neue IPs hinzugekommen (davon 943,458 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 4,771 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 188,120 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,935,765 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,340,145 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,338,145 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-09T14:45 bis 2026-09-10T05:19 UTC
