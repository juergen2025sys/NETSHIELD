# ✅ OK

0 Rückfälle - keine der 0 eingefrorenen IPs taucht in 0 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-26 00:18 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,817 (Anstieg) (jetzt 8,961,921)
- seit Zyklus-Start (2026-08-23): 📉 -434,118 (Rückgang)
- letzter combined-Cleanup-Pass: 618,673 IPs durch Ablauf entfernt (davon 618,673 Watchlist/30T, 0 Active/180T), 1,862,370 neue IPs hinzugekommen (davon 1,675,114 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 5 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 189,397 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,851,095 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 4,950,831 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,950,831 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-08-25T13:03 bis 2026-08-25T21:59 UTC
