# ✅ OK

0 Rückfälle - keine der 1,022,361 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-08 07:30 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -509,928 (Rückgang) (jetzt 10,720,545)
- seit Zyklus-Start (2026-08-23): 📈 +1,324,506 (Anstieg)
- letzter combined-Cleanup-Pass: 292,896 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 292,896 Active/180T), 1,277,049 neue IPs hinzugekommen (davon 946,155 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 997 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 189,193 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,351,668 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,380,926 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,380,926 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-07T12:18 bis 2026-09-08T05:17 UTC
