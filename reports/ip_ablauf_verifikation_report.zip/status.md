# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 176803 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-09-03 01:17 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,148,706)
- seit Zyklus-Start (2026-08-23): 📈 +1,752,667 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 1,018,824 neue IPs hinzugekommen (davon 803,330 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 24,987 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 192,928 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,524,389 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 0 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 14/14 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 2 sonstige, Zeitraum 2026-09-02T06:27 bis 2026-09-02T23:14 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| active_blacklist_ipv4.txt | 120 | 101.53.250.20, 103.160.234.194, 103.182.69.27, 103.82.252.62, 104.207.57.110, ... |
| combined_threat_blacklist_ipv4_part1.txt | 83413 | 1.0.137.182, 1.1.176.123, 1.1.197.87, 1.1.221.157, 1.1.245.219, ... |
| combined_threat_blacklist_ipv4_part2.txt | 93390 | 112.122.11.132, 112.122.11.133, 112.122.236.205, 112.122.236.207, 112.122.236.220, ... |
| blacklist_confidence40_ipv4_part1.txt | 120 | 101.53.250.20, 103.160.234.194, 103.182.69.27, 103.82.252.62, 104.207.57.110, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
