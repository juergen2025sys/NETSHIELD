# ✅ OK

0 Rückfälle - keine der 836,201 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-17 13:36 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +16,024 (Anstieg) (jetzt 11,382,961)
- seit Zyklus-Start (2026-08-23): 📈 +1,986,922 (Anstieg)
- letzter combined-Cleanup-Pass: 244,214 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,214 Active/180T), 1,079,619 neue IPs hinzugekommen (davon 934,748 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 74 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 2 Whitelist-Bereinigung, 137,208 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,617,492 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,956,711 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,954,711 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-16T16:43 bis 2026-09-17T11:31 UTC
