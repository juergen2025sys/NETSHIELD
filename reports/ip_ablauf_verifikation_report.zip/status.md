# ✅ OK

0 Rückfälle - keine der 835,093 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-20 16:23 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,361 (Anstieg) (jetzt 11,606,039)
- seit Zyklus-Start (2026-08-23): 📈 +2,210,000 (Anstieg)
- letzter combined-Cleanup-Pass: 243,136 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,136 Active/180T), 1,068,669 neue IPs hinzugekommen (davon 936,730 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 131 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 129,844 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,618,362 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,948,163 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,948,163 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-19T20:31 bis 2026-09-20T12:34 UTC
