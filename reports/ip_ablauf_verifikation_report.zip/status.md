# ✅ OK

0 Rückfälle - keine der 3,060,001 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-13 13:19 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +16,368 (Anstieg) (jetzt 10,761,774)
- seit Zyklus-Start (2026-09-22): 📉 -715,945 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 874,779 neue IPs hinzugekommen (davon 734,985 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 403 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 123,492 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,145,155 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 3,231,861 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 6,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 3,225,861 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-12T06:35 bis 2026-10-13T11:08 UTC
