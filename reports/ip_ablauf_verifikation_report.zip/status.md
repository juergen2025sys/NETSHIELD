# ✅ OK

0 Rückfälle - keine der 853,495 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-23 19:37 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +4,403 (Anstieg) (jetzt 11,598,666)
- seit Zyklus-Start (2026-09-22): 📈 +120,947 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 936,345 neue IPs hinzugekommen (davon 807,682 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 336 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 3 Whitelist-Bereinigung, 124,470 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,697,494 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 15,041 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 13,041 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-22T21:39 bis 2026-09-23T17:28 UTC
