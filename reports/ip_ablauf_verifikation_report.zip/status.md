# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 176786 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-09-02 19:53 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +28,781 (Anstieg) (jetzt 11,138,217)
- seit Zyklus-Start (2026-08-23): 📈 +1,742,178 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 1,378,482 neue IPs hinzugekommen (davon 804,079 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 24,855 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 550,116 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,636,589 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-01T23:26 bis 2026-09-02T16:51 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| active_blacklist_ipv4.txt | 118 | 101.53.250.20, 103.160.234.194, 103.182.69.27, 103.82.252.62, 104.207.57.110, ... |
| combined_threat_blacklist_ipv4_part1.txt | 83403 | 1.0.137.182, 1.1.176.123, 1.1.197.87, 1.1.221.157, 1.1.245.219, ... |
| combined_threat_blacklist_ipv4_part2.txt | 93383 | 112.122.11.132, 112.122.11.133, 112.122.236.205, 112.122.236.207, 112.122.236.220, ... |
| blacklist_confidence40_ipv4_part1.txt | 118 | 101.53.250.20, 103.160.234.194, 103.182.69.27, 103.82.252.62, 104.207.57.110, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
