# ✅ OK

0 Rückfälle - keine der 0 eingefrorenen IPs taucht in 0 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-23 22:16 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +129 (Anstieg) (jetzt 9,411,830)
- seit Zyklus-Start (2026-08-23): 📈 +15,791 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 1,858,435 neue IPs hinzugekommen (davon 1,671,395 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 186,911 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): n/a (2/8 Läufe im Fenster mit Daten)
- entfernte IPs (Summe letzter Läufe): n/a (2/8 Läufe im Fenster mit Daten)
  - davon Watchlist/30 Tage: n/a (1/8 Läufe im Fenster mit Daten)
  - davon Active/180 Tage: n/a (1/8 Läufe im Fenster mit Daten)
- Erfolgsquote letzte 16 combined-Läufe: 9/11 erfolgreich (82%, nur echte Erfolge/Fehlschläge gezählt) | 5 sonstige, Zeitraum 2026-08-23T12:55 bis 2026-08-23T19:52 UTC
