# ✅ OK

0 Rückfälle - keine der 3,739,656 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-05 09:29 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +7,863 (Anstieg) (jetzt 11,167,849)
- seit Zyklus-Start (2026-10-22): 📈 +109,406 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 809,460 neue IPs hinzugekommen (davon 700,505 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 12 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,450 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,517,881 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 85,577 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 6,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 79,577 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-04T03:12 bis 2026-11-05T06:27 UTC
