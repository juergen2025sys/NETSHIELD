# ✅ OK

0 Rückfälle - keine der 4,360,078 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-23 14:54 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +17,753 (Anstieg) (jetzt 11,269,936)
- seit Zyklus-Start (2026-11-21): 📉 -2,274 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 914,162 neue IPs hinzugekommen (davon 804,623 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 210 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 106,925 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,240,965 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 27,498 | gestern 32,213 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 25,498 | gestern 30,213
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-22T12:56 bis 2026-11-23T13:40 UTC
