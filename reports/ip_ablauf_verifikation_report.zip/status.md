# ✅ OK

0 Rückfälle - keine der 1,021,917 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-09 01:47 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +238 (Anstieg) (jetzt 10,785,750)
- seit Zyklus-Start (2026-08-23): 📈 +1,389,711 (Anstieg)
- letzter combined-Cleanup-Pass: 294,249 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 292,249 Active/180T), 1,131,853 neue IPs hinzugekommen (davon 942,079 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 172 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 191,725 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,070,531 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,340,826 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,338,826 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-08T11:44 bis 2026-09-08T23:39 UTC
