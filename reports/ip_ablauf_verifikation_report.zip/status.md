# ✅ OK

0 Rückfälle - keine der 4,335,092 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-22 10:50 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +21,038 (Anstieg) (jetzt 11,257,207)
- seit Zyklus-Start (2026-11-21): 📉 -15,003 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 906,752 neue IPs hinzugekommen (davon 793,329 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 383 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,396 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,110,947 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 32,220 | gestern 62,183 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,117
  - davon Active/180 Tage: heute 30,220 | gestern 61,066
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-21T10:53 bis 2026-11-22T09:32 UTC
