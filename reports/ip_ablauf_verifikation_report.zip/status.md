# ✅ OK

0 Rückfälle - keine der 3,910,552 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-11 17:06 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +18,854 (Anstieg) (jetzt 11,260,037)
- seit Zyklus-Start (2026-10-22): 📈 +201,594 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 826,260 neue IPs hinzugekommen (davon 714,846 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 310 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,882 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,519,843 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 24,184 | gestern 33,667 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,157
  - davon Active/180 Tage: heute 22,184 | gestern 32,510
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-10T15:37 bis 2026-11-11T15:12 UTC
