# ✅ OK

0 Rückfälle - keine der 4,244,298 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-21 01:00 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,203 (Anstieg) (jetzt 11,272,210)
- seit Zyklus-Start (2026-11-21): n/a (kein Vergleichswert)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 822,988 neue IPs hinzugekommen (davon 713,544 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 107,340 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 822,988 (Summe 1 verschiedene Combined-Läufe in den letzten 1 Prüfläufen / 1 Lauf(e), noch keine 24h Historie seit Zyklus-Start; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 0 | gestern 27,979 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 0 | gestern 2,000
  - davon Active/180 Tage: heute 0 | gestern 25,979
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-20T02:27 bis 2026-11-20T21:29 UTC
