# ✅ OK

0 Rückfälle - keine der 3,993,669 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-15 16:53 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +17,518 (Anstieg) (jetzt 11,354,029)
- seit Zyklus-Start (2026-10-22): 📈 +295,586 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 822,157 neue IPs hinzugekommen (davon 712,825 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 205 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 103,972 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,759,083 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 19,363 | gestern 24,796 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 17,363 | gestern 22,796
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-14T15:45 bis 2026-11-15T15:49 UTC
