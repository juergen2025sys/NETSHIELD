# ✅ OK

0 Rückfälle - keine der 834,730 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-21 22:12 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,475,071)
- seit Zyklus-Start (2026-08-23): 📈 +2,079,032 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 954,364 neue IPs hinzugekommen (davon 827,519 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 119 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 126,117 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,113,157 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 974,270 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 972,270 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-21T00:37 bis 2026-09-21T20:07 UTC
