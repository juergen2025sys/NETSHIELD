# ✅ OK

0 Rückfälle - keine der 835,393 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-19 15:36 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +5,440 (Anstieg) (jetzt 11,542,682)
- seit Zyklus-Start (2026-08-23): 📈 +2,146,643 (Anstieg)
- letzter combined-Cleanup-Pass: 243,668 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,668 Active/180T), 1,074,664 neue IPs hinzugekommen (davon 937,180 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 84 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 132,322 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,594,612 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,950,944 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,950,944 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-18T21:15 bis 2026-09-19T13:14 UTC
