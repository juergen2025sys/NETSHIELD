# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 25366 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-11-09 02:20 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,199,190)
- seit Zyklus-Start (2026-10-22): 📈 +140,747 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 807,969 neue IPs hinzugekommen (davon 704,876 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 20 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 107,436 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 3,248,893 (Summe 4 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 27,366 | gestern 27,115 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,149
  - davon Active/180 Tage: heute 25,366 | gestern 25,966
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-08T00:23 bis 2026-11-09T01:13 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| combined_threat_blacklist_ipv4_part1.txt | 11195 | 1.0.140.159, 1.0.140.187, 1.0.140.67, 1.0.211.191, 1.0.213.88, ... |
| combined_threat_blacklist_ipv4_part2.txt | 14171 | 113.215.221.95, 113.219.124.208, 113.221.14.98, 113.221.44.99, 113.221.45.92, ... |
| blacklist_confidence40_ipv4_part1.txt | 19722 | 1.0.140.159, 1.0.140.187, 1.0.140.67, 1.0.211.191, 1.0.213.88, ... |
| blacklist_confidence40_ipv4_part2.txt | 5644 | 31.176.133.184, 31.176.140.100, 31.176.144.41, 31.176.144.88, 31.176.156.48, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
