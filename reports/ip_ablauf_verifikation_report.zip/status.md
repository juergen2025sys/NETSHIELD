# ✅ OK

0 Rückfälle - keine der 4,467,851 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-27 12:25 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +10,973 (Anstieg) (jetzt 11,308,698)
- seit Zyklus-Start (2026-11-21): 📈 +36,488 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 915,899 neue IPs hinzugekommen (davon 800,633 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 7,112 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 107,540 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,360,560 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 29,692 | gestern 29,420 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 914
  - davon Active/180 Tage: heute 27,692 | gestern 28,506
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-26T03:40 bis 2026-11-27T09:06 UTC
