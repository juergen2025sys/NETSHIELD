# ✅ OK

0 Rückfälle - keine der 627,009 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-25 18:27 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +4,074 (Anstieg) (jetzt 8,952,071)
- seit Zyklus-Start (2026-08-23): 📉 -443,968 (Rückgang)
- letzter combined-Cleanup-Pass: 618,721 IPs durch Ablauf entfernt (davon 618,721 Watchlist/30T, 0 Active/180T), 1,865,228 neue IPs hinzugekommen (davon 1,676,399 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 41 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 189,234 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,849,023 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 4,951,681 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,951,681 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-25T04:23 bis 2026-08-25T16:17 UTC
