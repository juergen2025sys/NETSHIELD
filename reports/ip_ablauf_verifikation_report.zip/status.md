# ✅ OK

0 Rückfälle - keine der 4,576,218 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-28 03:59 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -54,216 (Rückgang) (jetzt 11,298,412)
- seit Zyklus-Start (2026-11-21): 📈 +26,202 (Anstieg)
- letzter combined-Cleanup-Pass: 110,936 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 108,936 Active/180T), 1,040,092 neue IPs hinzugekommen (davon 913,401 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 8,445 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,865 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,469,568 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 110,936 | gestern 29,692 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 108,936 | gestern 27,692
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-27T00:00 bis 2026-11-28T01:32 UTC
