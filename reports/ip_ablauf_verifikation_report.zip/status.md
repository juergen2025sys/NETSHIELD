# ✅ OK

0 Rückfälle - keine der 360,091 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-08 00:49 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +16,193 (Anstieg) (jetzt 11,230,473)
- seit Zyklus-Start (2026-08-23): 📈 +1,834,434 (Anstieg)
- letzter combined-Cleanup-Pass: 155,446 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,446 Active/180T), 1,030,777 neue IPs hinzugekommen (davon 829,505 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 334 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 189,349 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,078,258 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,245,389 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,243,389 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-06T23:10 bis 2026-09-07T21:28 UTC
