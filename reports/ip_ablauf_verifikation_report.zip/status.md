# ✅ OK

0 Rückfälle - keine der 3,975,630 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-14 02:55 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -22,249 (Rückgang) (jetzt 11,312,273)
- seit Zyklus-Start (2026-10-22): 📈 +253,830 (Anstieg)
- letzter combined-Cleanup-Pass: 24,797 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 22,797 Active/180T), 817,850 neue IPs hinzugekommen (davon 711,115 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 23 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 105,277 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,748,698 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 24,797 | gestern 20,675 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,154
  - davon Active/180 Tage: heute 22,797 | gestern 19,521
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-13T07:23 bis 2026-11-14T01:49 UTC
