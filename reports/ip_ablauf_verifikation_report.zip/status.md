# ✅ OK

0 Rückfälle - keine der 835,950 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-18 03:28 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +5,132 (Anstieg) (jetzt 11,419,446)
- seit Zyklus-Start (2026-08-23): 📈 +2,023,407 (Anstieg)
- letzter combined-Cleanup-Pass: 246,118 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 244,118 Active/180T), 1,072,814 neue IPs hinzugekommen (davon 934,720 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 3 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 136,855 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,590,473 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,955,079 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,953,079 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 14/14 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 2 cancelled (nicht gewertet), Zeitraum 2026-09-17T06:43 bis 2026-09-18T00:36 UTC
