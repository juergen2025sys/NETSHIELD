# ✅ OK

0 Rückfälle - keine der 835,279 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-20 01:48 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,575 (Anstieg) (jetzt 11,570,463)
- seit Zyklus-Start (2026-08-23): 📈 +2,174,424 (Anstieg)
- letzter combined-Cleanup-Pass: 243,581 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,581 Active/180T), 1,072,184 neue IPs hinzugekommen (davon 936,424 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 90 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 129,462 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,616,345 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,949,717 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,949,717 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-19T09:44 bis 2026-09-19T23:34 UTC
