# ✅ OK

0 Rückfälle - keine der 3,253,353 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-20 14:07 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +23,378 (Anstieg) (jetzt 10,999,421)
- seit Zyklus-Start (2026-09-22): 📉 -478,298 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 893,084 neue IPs hinzugekommen (davon 765,411 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 19 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 121,291 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,149,466 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 13,053 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 11,053 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-19T13:58 bis 2026-10-20T10:18 UTC
