# ✅ OK

0 Rückfälle - keine der 836,031 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-17 22:13 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +9,715 (Anstieg) (jetzt 11,410,254)
- seit Zyklus-Start (2026-08-23): 📈 +2,014,215 (Anstieg)
- letzter combined-Cleanup-Pass: 244,137 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,137 Active/180T), 1,068,935 neue IPs hinzugekommen (davon 934,284 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 2 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 132,652 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,617,068 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,955,443 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,953,443 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 14/14 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 2 cancelled (nicht gewertet), Zeitraum 2026-09-16T23:52 bis 2026-09-17T19:02 UTC
