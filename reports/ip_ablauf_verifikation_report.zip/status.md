# ✅ OK

0 Rückfälle - keine der 4,305,157 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-21 12:56 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +7,886 (Anstieg) (jetzt 11,236,560)
- seit Zyklus-Start (2026-11-21): 📉 -35,650 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 845,503 neue IPs hinzugekommen (davon 727,096 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 234 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 110,713 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 3,349,577 (Summe 4 verschiedene Combined-Läufe in den letzten 4 Prüfläufen / 4 Lauf(e), noch keine 24h Historie seit Zyklus-Start; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 63,067 | gestern 27,157 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,178
  - davon Active/180 Tage: heute 61,067 | gestern 25,979
- Erfolgsquote letzte 16 combined-Läufe: 14/14 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet) | 1 sonstige, Zeitraum 2026-11-20T18:57 bis 2026-11-21T11:48 UTC
