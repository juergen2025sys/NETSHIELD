# ✅ OK

0 Rückfälle - keine der 1,410,606 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-11 08:41 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 12,273,613)
- seit Zyklus-Start (2026-09-22): 📈 +795,894 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 904,517 neue IPs hinzugekommen (davon 772,132 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 3,062 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 120,266 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,183,804 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 17,987 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 15,987 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-10-10T06:23 bis 2026-10-11T06:33 UTC
