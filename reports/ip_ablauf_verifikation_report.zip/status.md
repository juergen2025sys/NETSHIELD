# ✅ OK

0 Rückfälle - keine der 4,027,026 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-17 17:36 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +9,331 (Anstieg) (jetzt 11,379,379)
- seit Zyklus-Start (2026-10-22): 📈 +320,936 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 825,262 neue IPs hinzugekommen (davon 714,583 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 18 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,453 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,592,275 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 17,141 | gestern 19,007 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,175
  - davon Active/180 Tage: heute 15,141 | gestern 17,832
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-16T13:14 bis 2026-11-17T16:29 UTC
