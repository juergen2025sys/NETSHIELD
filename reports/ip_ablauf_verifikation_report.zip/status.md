# ✅ OK

0 Rückfälle - keine der 4,334,941 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-22 18:47 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,160 (Anstieg) (jetzt 11,262,927)
- seit Zyklus-Start (2026-11-21): 📉 -9,283 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 901,827 neue IPs hinzugekommen (davon 793,840 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 68 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 106,817 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,235,282 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 32,217 | gestern 62,182 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,117
  - davon Active/180 Tage: heute 30,217 | gestern 61,065
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-21T15:42 bis 2026-11-22T15:39 UTC
