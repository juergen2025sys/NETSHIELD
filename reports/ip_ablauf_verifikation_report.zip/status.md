# ✅ OK

0 Rückfälle - keine der 3,801,559 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-07 21:50 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,022 (Anstieg) (jetzt 11,194,167)
- seit Zyklus-Start (2026-10-22): 📈 +135,724 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 807,651 neue IPs hinzugekommen (davon 702,417 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 149 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,384 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,471,684 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 26,295 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 24,295 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-06T19:42 bis 2026-11-07T19:20 UTC
