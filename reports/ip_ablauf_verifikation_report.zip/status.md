# ✅ OK

0 Rückfälle - keine der 969,047 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-01 20:39 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,025 (Anstieg) (jetzt 12,021,115)
- seit Zyklus-Start (2026-09-22): 📈 +543,396 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 917,587 neue IPs hinzugekommen (davon 791,577 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 34 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 120,409 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,385,843 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 18,547 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 16,547 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-10-01T00:26 bis 2026-10-01T18:34 UTC
