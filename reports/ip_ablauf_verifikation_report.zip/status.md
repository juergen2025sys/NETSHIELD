# ✅ OK

0 Rückfälle - keine der 835,057 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-20 23:08 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,621,716)
- seit Zyklus-Start (2026-08-23): 📈 +2,225,677 (Anstieg)
- letzter combined-Cleanup-Pass: 243,104 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,104 Active/180T), 1,073,825 neue IPs hinzugekommen (davon 937,051 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 91 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 127,381 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,614,693 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,946,687 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,946,687 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-20T04:44 bis 2026-09-20T21:03 UTC
