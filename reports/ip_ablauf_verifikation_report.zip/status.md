# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 6430 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-09-22 02:27 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -3,556 (Rückgang) (jetzt 11,477,719)
- seit Zyklus-Start (2026-09-22): n/a (kein Vergleichswert)
- letzter combined-Cleanup-Pass: 8,430 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 6,430 Active/180T), 962,643 neue IPs hinzugekommen (davon 829,320 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 94 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 128,694 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 962,643 (Summe letzte 1 Läufe / 1 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- entfernte IPs (Summe letzter Läufe): 8,430 (Summe letzte 1 Läufe / 1 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 1 Läufe / 1 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Active/180 Tage: 6,430 (Summe letzte 1 Läufe / 1 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-21T05:30 bis 2026-09-22T00:17 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| blacklist_confidence40_ipv4_part2.txt | 6430 | 1.0.214.42, 1.10.240.249, 1.10.255.64, 1.159.189.158, 1.161.138.202, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
