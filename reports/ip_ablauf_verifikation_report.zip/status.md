# ✅ OK

0 Rückfälle - keine der 360,113 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-06 17:55 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +5,491 (Anstieg) (jetzt 11,130,332)
- seit Zyklus-Start (2026-08-23): 📈 +1,734,293 (Anstieg)
- letzter combined-Cleanup-Pass: 155,409 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,409 Active/180T), 1,031,663 neue IPs hinzugekommen (davon 842,605 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 1,614 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 187,838 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,065,394 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,243,847 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,243,847 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 14/15 erfolgreich (93%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-05T21:31 bis 2026-09-06T15:48 UTC
