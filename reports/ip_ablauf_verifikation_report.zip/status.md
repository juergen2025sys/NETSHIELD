# ✅ OK

0 Rückfälle - keine der 627,114 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-25 07:08 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +344 (Anstieg) (jetzt 8,936,798)
- seit Zyklus-Start (2026-08-23): 📉 -459,241 (Rückgang)
- letzter combined-Cleanup-Pass: 619,105 IPs durch Ablauf entfernt (davon 619,105 Watchlist/30T, 0 Active/180T), 1,854,705 neue IPs hinzugekommen (davon 1,671,625 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 5 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 187,176 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,876,479 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 4,965,722 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,965,722 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-24T19:17 bis 2026-08-25T04:23 UTC
