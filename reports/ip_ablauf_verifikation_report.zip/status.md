# ✅ OK

0 Rückfälle - keine der 360,114 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-06 16:08 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,642 (Anstieg) (jetzt 11,124,841)
- seit Zyklus-Start (2026-08-23): 📈 +1,728,802 (Anstieg)
- letzter combined-Cleanup-Pass: 155,410 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,410 Active/180T), 1,011,786 neue IPs hinzugekommen (davon 827,607 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 18 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 186,952 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,047,237 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,243,940 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,243,940 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-05T20:15 bis 2026-09-06T12:53 UTC
