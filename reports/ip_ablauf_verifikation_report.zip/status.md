# ✅ OK

0 Rückfälle - keine der 360,136 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-05 22:50 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,053,966)
- seit Zyklus-Start (2026-08-23): 📈 +1,657,927 (Anstieg)
- letzter combined-Cleanup-Pass: 155,502 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,502 Active/180T), 1,013,506 neue IPs hinzugekommen (davon 829,074 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 2 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 186,515 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,123,814 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,243,801 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,243,801 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-05T08:26 bis 2026-09-05T20:43 UTC
