# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 15987 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-10-11 02:38 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -10,441 (Rückgang) (jetzt 12,261,224)
- seit Zyklus-Start (2026-09-22): 📈 +783,505 (Anstieg)
- letzter combined-Cleanup-Pass: 17,987 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 15,987 Active/180T), 896,361 neue IPs hinzugekommen (davon 768,413 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 133 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 120,679 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,242,710 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 17,987 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 15,987 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-09T22:49 bis 2026-10-11T00:30 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| blacklist_confidence40_ipv4_part1.txt | 8720 | 1.117.72.154, 1.12.240.23, 1.162.112.3, 1.164.122.183, 1.164.245.237, ... |
| blacklist_confidence40_ipv4_part2.txt | 7267 | 13.217.145.147, 13.221.218.208, 13.221.98.163, 13.40.125.247, 13.71.169.84, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
