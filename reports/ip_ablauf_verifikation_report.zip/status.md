# ✅ OK

0 Rückfälle - keine der 840,567 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-16 01:43 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,292,784)
- seit Zyklus-Start (2026-08-23): 📈 +1,896,745 (Anstieg)
- letzter combined-Cleanup-Pass: 244,584 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,584 Active/180T), 1,043,946 neue IPs hinzugekommen (davon 935,775 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 278 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 4 Whitelist-Bereinigung, 94,483 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,572,859 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,960,076 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,958,076 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-15T04:43 bis 2026-09-15T21:46 UTC
