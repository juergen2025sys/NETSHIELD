# ✅ OK

0 Rückfälle - keine der 1,338,949 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-09 22:22 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +4,961 (Anstieg) (jetzt 12,236,513)
- seit Zyklus-Start (2026-09-22): 📈 +758,794 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 917,694 neue IPs hinzugekommen (davon 792,348 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 248 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 120,685 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,377,127 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 445,250 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 441,250 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-08T19:00 bis 2026-10-09T18:31 UTC
