# ✅ OK

0 Rückfälle - keine der 1,410,522 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-11 20:28 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +5,774 (Anstieg) (jetzt 12,301,285)
- seit Zyklus-Start (2026-09-22): 📈 +823,566 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 893,021 neue IPs hinzugekommen (davon 769,230 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 13 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 118,286 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,189,610 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 17,987 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 15,987 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-10T16:00 bis 2026-10-11T15:52 UTC
