# ✅ OK

0 Rückfälle - keine der 835,047 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-21 01:12 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +1,155 (Anstieg) (jetzt 11,622,871)
- seit Zyklus-Start (2026-08-23): 📈 +2,226,832 (Anstieg)
- letzter combined-Cleanup-Pass: 243,092 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,092 Active/180T), 1,065,442 neue IPs hinzugekommen (davon 937,360 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 68 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 127,193 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,591,720 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,945,737 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,945,737 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-20T05:25 bis 2026-09-20T23:09 UTC
