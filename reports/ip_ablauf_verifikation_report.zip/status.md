# ✅ OK

0 Rückfälle - keine der 1,038,006 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-06 23:15 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,527 (Anstieg) (jetzt 12,331,014)
- seit Zyklus-Start (2026-09-22): 📈 +853,295 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 911,202 neue IPs hinzugekommen (davon 790,432 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 113 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 118,353 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,288,850 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 18,020 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 16,020 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 14/16 erfolgreich (88%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-06T00:46 bis 2026-10-06T19:52 UTC
