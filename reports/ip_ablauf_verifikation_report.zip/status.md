# ✅ OK

0 Rückfälle - keine der 4,305,049 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-21 20:53 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +13,034 (Anstieg) (jetzt 11,261,799)
- seit Zyklus-Start (2026-11-21): 📉 -10,411 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 903,546 neue IPs hinzugekommen (davon 791,983 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 613 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,454 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,122,109 (Summe 6 verschiedene Combined-Läufe in den letzten 6 Prüfläufen / 6 Lauf(e), noch keine 24h Historie seit Zyklus-Start; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 63,067 | gestern 27,156 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,178
  - davon Active/180 Tage: heute 61,067 | gestern 25,978
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-11-21T00:49 bis 2026-11-21T19:48 UTC
