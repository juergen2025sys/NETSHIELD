# ✅ OK

0 Rückfälle - keine der 835,154 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-20 13:56 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,603,678)
- seit Zyklus-Start (2026-08-23): 📈 +2,207,639 (Anstieg)
- letzter combined-Cleanup-Pass: 243,532 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,532 Active/180T), 1,082,216 neue IPs hinzugekommen (davon 938,885 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 433 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 132,969 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,623,626 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,948,701 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,948,701 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-19T18:52 bis 2026-09-20T11:49 UTC
