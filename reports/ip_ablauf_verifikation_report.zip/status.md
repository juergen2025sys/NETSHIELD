# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 436 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-09-05 06:54 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +7,658 (Anstieg) (jetzt 11,035,985)
- seit Zyklus-Start (2026-08-23): 📈 +1,639,946 (Anstieg)
- letzter combined-Cleanup-Pass: 155,449 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,449 Active/180T), 1,022,033 neue IPs hinzugekommen (davon 830,249 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 3,040 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 188,505 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
- entfernte IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
  - davon Watchlist/30 Tage: n/a (7/8 Läufe im Fenster mit Daten)
  - davon Active/180 Tage: n/a (7/8 Läufe im Fenster mit Daten)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-04T13:51 bis 2026-09-05T04:44 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| active_blacklist_ipv4.txt | 223 | 101.53.250.20, 102.129.153.207, 102.129.56.183, 102.64.41.246, 102.88.111.27, ... |
| combined_threat_blacklist_ipv4_part1.txt | 114 | 101.53.250.20, 102.129.153.207, 102.129.56.183, 102.64.41.246, 102.88.111.27, ... |
| combined_threat_blacklist_ipv4_part2.txt | 322 | 113.161.44.1, 113.23.35.151, 113.57.184.205, 115.186.103.226, 115.241.25.146, ... |
| blacklist_confidence40_ipv4_part1.txt | 223 | 101.53.250.20, 102.129.153.207, 102.129.56.183, 102.64.41.246, 102.88.111.27, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
