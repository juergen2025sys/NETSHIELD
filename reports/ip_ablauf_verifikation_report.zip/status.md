# ✅ OK

0 Rückfälle - keine der 836,340 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-16 23:49 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +11,281 (Anstieg) (jetzt 11,355,931)
- seit Zyklus-Start (2026-08-23): 📈 +1,959,892 (Anstieg)
- letzter combined-Cleanup-Pass: 244,216 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,216 Active/180T), 1,073,004 neue IPs hinzugekommen (davon 933,881 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 70 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 Whitelist-Bereinigung, 133,799 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,583,147 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,957,795 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,955,795 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-16T05:18 bis 2026-09-16T21:43 UTC
