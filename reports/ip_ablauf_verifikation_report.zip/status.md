# ❌ ALARM

**1 Problem(e) erkannt:**

- 🛑 **Ledger-Sanity-Guard ausgelöst (Watchlist):** Ein combined-Lauf wollte mehr als die Hälfte des watchlist_expired_history-Ledgers auf einen Schlag entfernen - wurde blockiert, alter Stand bleibt erhalten (siehe Bug 17: exakt so ist der Ledger vorher von 657.370 auf 0 gefallen). Zwei mögliche Ursachen, beide erfordern einen Blick ins combined-Log dieses Laufs: (1) ein neuer Bug im Prune-Vergleich, oder (2) eine große, an einem einzigen Kalendertag entstandene Kohorte wird 14 Tage später geschlossen prune-fällig (eingefroren_am ist datumsgranular, keine Uhrzeit) - das wäre legitim, kein Bug. Vor jeder Änderung am Schwellenwert prüfen, ob die betroffenen Einträge tatsächlich alle exakt denselben eingefroren_am-Wert haben.

Lauf: 2026-09-15 07:37 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +10,508 (Anstieg) (jetzt 11,201,054)
- seit Zyklus-Start (2026-08-23): 📈 +1,805,015 (Anstieg)
- letzter combined-Cleanup-Pass: 246,987 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 244,987 Active/180T), 1,043,403 neue IPs hinzugekommen (davon 938,322 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 4,793 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 94,242 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,612,089 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,962,583 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,960,583 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-14T12:32 bis 2026-09-15T05:23 UTC

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
