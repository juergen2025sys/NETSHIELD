# ✅ OK

0 Rückfälle - keine der 183,250 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-29 16:39 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +7,531 (Anstieg) (jetzt 9,533,394)
- seit Zyklus-Start (2026-08-23): 📈 +137,355 (Anstieg)
- letzter combined-Cleanup-Pass: 162,299 IPs durch Ablauf entfernt (davon 162,299 Watchlist/30T, 0 Active/180T), 1,863,135 neue IPs hinzugekommen (davon 1,683,249 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 37 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 191,540 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
- entfernte IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
  - davon Watchlist/30 Tage: n/a (7/8 Läufe im Fenster mit Daten)
  - davon Active/180 Tage: n/a (7/8 Läufe im Fenster mit Daten)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-28T14:21 bis 2026-08-29T13:09 UTC
