# ✅ OK

0 Rückfälle - keine der 360,118 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-06 13:27 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,118,199)
- seit Zyklus-Start (2026-08-23): 📈 +1,722,160 (Anstieg)
- letzter combined-Cleanup-Pass: 155,501 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,501 Active/180T), 1,018,791 neue IPs hinzugekommen (davon 828,691 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 295 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 3 Whitelist-Bereinigung, 188,580 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,051,119 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,244,032 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,244,032 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-05T18:38 bis 2026-09-06T11:21 UTC
