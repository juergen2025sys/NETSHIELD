# ✅ OK

0 Rückfälle - keine der 1,410,558 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-11 15:27 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +21,898 (Anstieg) (jetzt 12,295,511)
- seit Zyklus-Start (2026-09-22): 📈 +817,792 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 902,744 neue IPs hinzugekommen (davon 769,405 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 183 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 118,230 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,188,724 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 17,987 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 15,987 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-10T12:48 bis 2026-10-11T13:12 UTC
