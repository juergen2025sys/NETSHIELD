# ✅ OK

0 Rückfälle - keine der 4,045,926 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-18 20:26 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +14,283 (Anstieg) (jetzt 11,397,165)
- seit Zyklus-Start (2026-10-22): 📈 +338,722 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 821,773 neue IPs hinzugekommen (davon 712,792 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 17 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 106,985 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,604,264 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 21,380 | gestern 17,139 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 19,380 | gestern 15,139
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-17T16:18 bis 2026-11-18T19:10 UTC
