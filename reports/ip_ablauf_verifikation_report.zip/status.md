# ✅ OK

0 Rückfälle - keine der 1,038,736 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-06 04:33 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -14,715 (Rückgang) (jetzt 12,278,090)
- seit Zyklus-Start (2026-09-22): 📈 +800,371 (Anstieg)
- letzter combined-Cleanup-Pass: 18,020 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 16,020 Active/180T), 910,146 neue IPs hinzugekommen (davon 788,993 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 139 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 118,765 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,228,001 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 18,020 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 16,020 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-05T06:14 bis 2026-10-06T00:46 UTC
