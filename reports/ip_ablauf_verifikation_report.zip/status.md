# ✅ OK

0 Rückfälle - keine der 4,412,773 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-25 17:01 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +9,539 (Anstieg) (jetzt 11,288,835)
- seit Zyklus-Start (2026-11-21): 📈 +16,625 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 913,014 neue IPs hinzugekommen (davon 800,468 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 214 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,231 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,287,120 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 29,323 | gestern 28,297 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 27,323 | gestern 26,297
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-24T14:03 bis 2026-11-25T15:58 UTC
