# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 32900 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-10-14 02:47 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -7,722 (Rückgang) (jetzt 10,769,450)
- seit Zyklus-Start (2026-09-22): 📉 -708,269 (Rückgang)
- letzter combined-Cleanup-Pass: 34,900 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 32,900 Active/180T), 869,397 neue IPs hinzugekommen (davon 733,350 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 18 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 125,213 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,121,223 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 3,198,282 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 6,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 3,192,282 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-12T21:20 bis 2026-10-14T00:37 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| blacklist_confidence40_ipv4_part1.txt | 30248 | 1.1.241.197, 1.10.205.60, 1.10.255.186, 1.123.131.149, 1.123.231.55, ... |
| blacklist_confidence40_ipv4_part2.txt | 2652 | 198.190.0.190, 198.44.166.143, 198.46.241.238, 2.22.250.84, 2.63.200.140, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
