# ✅ OK

0 Rückfälle - keine der 1,019,858 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-12 17:56 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +1,713 (Anstieg) (jetzt 11,057,581)
- seit Zyklus-Start (2026-08-23): 📈 +1,661,542 (Anstieg)
- letzter combined-Cleanup-Pass: 245,477 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 245,477 Active/180T), 1,066,229 neue IPs hinzugekommen (davon 932,257 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 34 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 geschützt entfernt, 136,342 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,364,256 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,965,030 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,963,030 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 13/15 erfolgreich (87%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-12T04:23 bis 2026-09-12T15:50 UTC
