# ✅ OK

0 Rückfälle - keine der 4,385,822 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-24 23:47 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +7,696 (Anstieg) (jetzt 11,288,357)
- seit Zyklus-Start (2026-11-21): 📈 +16,147 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 907,522 neue IPs hinzugekommen (davon 798,567 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 126 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 109,188 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,462,822 (Summe 6 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 28,300 | gestern 27,494 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 26,300 | gestern 25,494
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-23T18:43 bis 2026-11-24T21:38 UTC
