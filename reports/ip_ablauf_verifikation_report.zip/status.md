# ✅ OK

0 Rückfälle - keine der 3,993,566 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-16 00:17 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,346 (Anstieg) (jetzt 11,361,396)
- seit Zyklus-Start (2026-10-22): 📈 +302,953 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 818,640 neue IPs hinzugekommen (davon 712,823 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 14 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 104,563 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,570,851 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 0 | gestern 19,363 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 0 | gestern 2,000
  - davon Active/180 Tage: heute 0 | gestern 17,363
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-14T22:44 bis 2026-11-15T23:10 UTC
