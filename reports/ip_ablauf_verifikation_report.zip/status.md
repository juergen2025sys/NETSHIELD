# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 35410 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-08-25 00:35 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 8,932,302)
- seit Zyklus-Start (2026-08-23): 📉 -463,737 (Rückgang)
- letzter combined-Cleanup-Pass: 616,821 IPs durch Ablauf entfernt (davon 616,821 Watchlist/30T, 0 Active/180T), 1,858,123 neue IPs hinzugekommen (davon 1,671,499 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 43 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 187,897 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,867,520 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 4,934,686 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,934,686 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 14/15 erfolgreich (93%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-08-24T14:21 bis 2026-08-24T22:01 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| active_blacklist_ipv4.txt | 35410 | 1.0.218.230, 1.1.202.148, 1.11.62.185, 1.11.62.186, 1.116.214.66, ... |
| combined_threat_blacklist_ipv4_part1.txt | 12671 | 1.0.218.230, 1.1.202.148, 1.11.62.185, 1.11.62.186, 1.116.214.66, ... |
| combined_threat_blacklist_ipv4_part2.txt | 22739 | 112.245.55.60, 112.245.59.63, 112.250.110.172, 112.252.132.185, 113.100.186.171, ... |
| blacklist_confidence40_ipv4_part1.txt | 35410 | 1.0.218.230, 1.1.202.148, 1.11.62.185, 1.11.62.186, 1.116.214.66, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
