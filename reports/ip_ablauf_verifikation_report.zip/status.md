# ✅ OK

0 Rückfälle - keine der 3,828,374 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-08 21:04 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,197,257)
- seit Zyklus-Start (2026-10-22): 📈 +138,814 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 809,315 neue IPs hinzugekommen (davon 705,060 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 46 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 4 Whitelist-Bereinigung, 107,781 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,057,223 (Summe 5 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 27,966 | gestern 26,290 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 25,966 | gestern 24,290
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-07T19:20 bis 2026-11-08T19:58 UTC
