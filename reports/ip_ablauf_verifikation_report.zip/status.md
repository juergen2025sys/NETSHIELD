# ✅ OK

0 Rückfälle - keine der 836,437 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-16 16:51 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +10,133 (Anstieg) (jetzt 11,337,080)
- seit Zyklus-Start (2026-08-23): 📈 +1,941,041 (Anstieg)
- letzter combined-Cleanup-Pass: 244,330 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,330 Active/180T), 1,075,194 neue IPs hinzugekommen (davon 935,025 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 56 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 135,879 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,525,962 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,958,519 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,956,519 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-15T18:01 bis 2026-09-16T14:50 UTC
