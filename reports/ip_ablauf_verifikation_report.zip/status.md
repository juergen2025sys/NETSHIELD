# ✅ OK

0 Rückfälle - keine der 1,020,252 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-12 03:31 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +745 (Anstieg) (jetzt 11,010,142)
- seit Zyklus-Start (2026-08-23): 📈 +1,614,103 (Anstieg)
- letzter combined-Cleanup-Pass: 247,470 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 245,470 Active/180T), 1,073,770 neue IPs hinzugekommen (davon 939,449 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 37 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 geschützt entfernt, 135,699 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,598,271 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,966,090 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,964,090 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-11T11:49 bis 2026-09-12T00:30 UTC
