# ✅ OK

0 Rückfälle - keine der 3,290,091 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-23 00:01 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,118,292)
- seit Zyklus-Start (2026-10-22): 📈 +59,849 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 889,584 neue IPs hinzugekommen (davon 763,395 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 178 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 121,276 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,240,187 (Summe letzte 7 Läufe / 7 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- entfernte IPs (Summe letzter Läufe): 32,437 (Summe letzte 7 Läufe / 7 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 7 Läufe / 7 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Active/180 Tage: 30,437 (Summe letzte 7 Läufe / 7 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-22T05:07 bis 2026-10-22T21:55 UTC
