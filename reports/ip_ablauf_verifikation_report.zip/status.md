# ✅ OK

0 Rückfälle - keine der 840,719 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-22 23:44 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +5,139 (Anstieg) (jetzt 11,533,264)
- seit Zyklus-Start (2026-09-22): 📈 +55,545 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 959,618 neue IPs hinzugekommen (davon 831,040 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 83 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 123,679 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,686,302 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 8,430 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 6,430 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-22T05:24 bis 2026-09-22T21:39 UTC
