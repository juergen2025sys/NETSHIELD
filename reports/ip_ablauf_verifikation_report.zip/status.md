# ✅ OK

0 Rückfälle - keine der 3,739,709 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-05 02:55 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,159,986)
- seit Zyklus-Start (2026-10-22): 📈 +101,543 (Anstieg)
- letzter combined-Cleanup-Pass: 27,087 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 25,087 Active/180T), 809,886 neue IPs hinzugekommen (davon 700,921 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 15 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,635 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,530,092 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 85,577 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 6,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 79,577 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-04T01:31 bis 2026-11-05T01:49 UTC
