# ✅ OK

0 Rückfälle - keine der 0 eingefrorenen IPs taucht in 0 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-26 09:40 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 9,591,725)
- seit Zyklus-Start (2026-08-23): 📈 +195,686 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 1,866,886 neue IPs hinzugekommen (davon 1,675,927 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 38 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 190,090 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 16,176,844 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,867,581 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 1,867,581 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-25T21:00 bis 2026-08-26T07:32 UTC
