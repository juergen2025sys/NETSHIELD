# ✅ OK

0 Rückfälle - keine der 840,841 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-15 09:39 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +25,772 (Anstieg) (jetzt 11,226,826)
- seit Zyklus-Start (2026-08-23): 📈 +1,830,787 (Anstieg)
- letzter combined-Cleanup-Pass: 244,941 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,941 Active/180T), 1,094,939 neue IPs hinzugekommen (davon 934,122 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 342 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 2 Whitelist-Bereinigung, 138,685 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,622,926 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,962,145 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,960,145 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-14T12:41 bis 2026-09-15T06:36 UTC
