# ✅ OK

0 Rückfälle - keine der 933,888 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-29 02:22 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,381 (Anstieg) (jetzt 11,847,341)
- seit Zyklus-Start (2026-09-22): 📈 +369,622 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 925,953 neue IPs hinzugekommen (davon 795,304 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 255 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 124,642 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,393,358 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 13,588 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 11,588 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-28T05:39 bis 2026-09-28T21:22 UTC
