# ✅ OK

0 Rückfälle - keine der 1,478,764 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-12 03:44 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 12,250,518)
- seit Zyklus-Start (2026-09-22): 📈 +772,799 (Anstieg)
- letzter combined-Cleanup-Pass: 68,479 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 66,479 Active/180T), 895,282 neue IPs hinzugekommen (davon 769,234 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 114 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 121,716 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,182,958 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 136,958 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 132,958 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-11T05:34 bis 2026-10-12T00:43 UTC
