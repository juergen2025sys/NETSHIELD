# ✅ OK

0 Rückfälle - keine der 360,107 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-06 21:30 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +21,557 (Anstieg) (jetzt 11,150,438)
- seit Zyklus-Start (2026-08-23): 📈 +1,754,399 (Anstieg)
- letzter combined-Cleanup-Pass: 155,407 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,407 Active/180T), 1,034,977 neue IPs hinzugekommen (davon 829,399 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 230 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 188,293 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,135,379 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,243,650 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,243,650 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-05T22:48 bis 2026-09-06T18:32 UTC
