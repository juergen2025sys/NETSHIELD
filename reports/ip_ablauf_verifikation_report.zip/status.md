# ✅ OK

0 Rückfälle - keine der 1,020,693 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-11 07:29 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +9,610 (Anstieg) (jetzt 10,935,002)
- seit Zyklus-Start (2026-08-23): 📈 +1,538,963 (Anstieg)
- letzter combined-Cleanup-Pass: 274,660 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 274,660 Active/180T), 1,143,129 neue IPs hinzugekommen (davon 943,796 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 4,206 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 195,833 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,133,640 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,280,449 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,278,449 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-10T16:17 bis 2026-09-11T05:17 UTC
