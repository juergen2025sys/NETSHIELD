# ✅ OK

0 Rückfälle - keine der 890,431 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-25 14:28 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +8,024 (Anstieg) (jetzt 11,677,487)
- seit Zyklus-Start (2026-09-22): 📈 +199,768 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 957,630 neue IPs hinzugekommen (davon 827,558 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 12 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,244 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,660,257 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 22,902 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 20,902 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-24T17:01 bis 2026-09-25T12:16 UTC
