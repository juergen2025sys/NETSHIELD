# ✅ OK

0 Rückfälle - keine der 627,052 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-25 12:23 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +1,515 (Anstieg) (jetzt 8,944,199)
- seit Zyklus-Start (2026-08-23): 📉 -451,840 (Rückgang)
- letzter combined-Cleanup-Pass: 618,754 IPs durch Ablauf entfernt (davon 618,754 Watchlist/30T, 0 Active/180T), 1,816,663 neue IPs hinzugekommen (davon 1,675,695 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 34 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 143,929 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,840,926 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 4,964,057 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,964,057 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-25T00:40 bis 2026-08-25T10:12 UTC
