# ✅ OK

0 Rückfälle - keine der 1,021,789 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-09 07:37 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +25,290 (Anstieg) (jetzt 10,811,040)
- seit Zyklus-Start (2026-08-23): 📈 +1,415,001 (Anstieg)
- letzter combined-Cleanup-Pass: 292,672 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 292,672 Active/180T), 1,139,753 neue IPs hinzugekommen (davon 942,118 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 368 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 191,051 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,081,681 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,340,938 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,338,938 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-08T16:50 bis 2026-09-09T05:18 UTC
