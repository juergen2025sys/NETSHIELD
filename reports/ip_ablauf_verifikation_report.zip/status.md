# ✅ OK

0 Rückfälle - keine der 4,440,854 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-26 14:30 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +30,794 (Anstieg) (jetzt 11,308,792)
- seit Zyklus-Start (2026-11-21): 📈 +36,582 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 908,861 neue IPs hinzugekommen (davon 801,618 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 257 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 104,262 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,374,176 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 30,508 | gestern 28,316 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 998
  - davon Active/180 Tage: heute 28,508 | gestern 27,318
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-25T14:30 bis 2026-11-26T13:13 UTC
