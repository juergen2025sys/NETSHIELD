# ❌ ALARM

**2 Problem(e) erkannt:**

- ❌ **Rückfall:** 62683 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.
- ⚠️ **Niedrige combined-Erfolgsquote:** nur 7/15 erfolgreich (47%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-08-23T21:57 bis 2026-08-24T04:32 UTC in den letzten 16 Läufen (Schwelle: 75%, cancelled nicht mitgezaehlt) - auch wenn der neueste Stand frisch wirkt, lief das System zuletzt nicht zuverlässig.

Lauf: 2026-08-24 07:21 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 8,772,949)
- seit Zyklus-Start (2026-08-23): 📉 -623,090 (Rückgang)
- letzter combined-Cleanup-Pass: 657,370 IPs durch Ablauf entfernt (davon 657,370 Watchlist/30T, 0 Active/180T), 1,968,228 neue IPs hinzugekommen (davon 1,767,036 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 187,059 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 15,203,601 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 3,944,238 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 3,944,238 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 🔍 7/15 erfolgreich (47%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-08-23T21:57 bis 2026-08-24T04:32 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| bot_detector_blacklist_ipv4.txt | 29527 | 1.0.0.104, 1.0.171.2, 1.0.215.7, 1.0.227.38, 1.1.187.152, ... |
| honeypot_ips.txt | 34732 | 1.0.218.230, 1.1.202.148, 1.11.62.185, 1.11.62.186, 1.116.214.66, ... |
| honigtopf_ips.txt | 9 | 122.97.137.17, 129.226.193.45, 147.182.205.127, 157.245.152.222, 220.125.130.67, ... |
| tweetfeed_ips.txt | 64 | 1.0.2.0, 103.214.172.14, 115.226.251.119, 123.5.149.113, 13.140.8.25, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
