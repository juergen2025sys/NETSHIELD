# ✅ OK

0 Rückfälle - keine der 4,244,395 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-20 19:01 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,795 (Anstieg) (jetzt 11,266,015)
- seit Zyklus-Start (2026-10-22): 📈 +207,572 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 823,946 neue IPs hinzugekommen (davon 713,828 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 138 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,518 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,593,830 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 27,980 | gestern 175,095 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 25,980 | gestern 173,095
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-19T20:26 bis 2026-11-20T16:10 UTC
