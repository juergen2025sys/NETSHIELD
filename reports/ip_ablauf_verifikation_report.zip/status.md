# ✅ OK

0 Rückfälle - keine der 1,018,733 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-12 23:08 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,938 (Anstieg) (jetzt 11,065,480)
- seit Zyklus-Start (2026-08-23): 📈 +1,669,441 (Anstieg)
- letzter combined-Cleanup-Pass: 245,453 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 245,453 Active/180T), 1,069,447 neue IPs hinzugekommen (davon 933,801 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 209 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 geschützt entfernt, 135,789 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,354,742 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,964,956 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,962,956 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-12T09:38 bis 2026-09-12T20:57 UTC
