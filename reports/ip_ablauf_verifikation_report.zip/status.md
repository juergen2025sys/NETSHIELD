# ✅ OK

0 Rückfälle - keine der 3,414,533 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-26 02:37 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -18,722 (Rückgang) (jetzt 11,147,495)
- seit Zyklus-Start (2026-10-22): 📈 +89,052 (Anstieg)
- letzter combined-Cleanup-Pass: 22,152 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 20,152 Active/180T), 808,531 neue IPs hinzugekommen (davon 744,948 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 101 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 60,460 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,482,974 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 22,152 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 20,152 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-10-25T11:52 bis 2026-10-26T00:46 UTC
