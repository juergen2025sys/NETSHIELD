# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 2687 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-08-30 07:06 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -13,605 (Rückgang) (jetzt 9,532,594)
- seit Zyklus-Start (2026-08-23): 📈 +136,555 (Anstieg)
- letzter combined-Cleanup-Pass: 177,250 IPs durch Ablauf entfernt (davon 177,250 Watchlist/30T, 0 Active/180T), 1,856,773 neue IPs hinzugekommen (davon 1,684,040 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 26 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 190,516 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,874,205 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,313,269 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 1,313,269 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-08-29T09:57 bis 2026-08-30T04:46 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| blacklist_confidence40_ipv4_part1.txt | 2687 | 1.14.43.163, 1.14.47.143, 1.14.75.122, 1.178.132.252, 1.181.190.201, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
