# ✅ OK

0 Rückfälle - keine der 1,021,521 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-09 23:25 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +1,348 (Anstieg) (jetzt 10,836,691)
- seit Zyklus-Start (2026-08-23): 📈 +1,440,652 (Anstieg)
- letzter combined-Cleanup-Pass: 292,236 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 292,236 Active/180T), 1,078,197 neue IPs hinzugekommen (davon 939,424 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 3 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 141,566 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,001,572 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,341,195 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,339,195 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-09T05:00 bis 2026-09-09T21:12 UTC
