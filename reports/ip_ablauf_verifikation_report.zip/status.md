# ✅ OK

0 Rückfälle - keine der 0 eingefrorenen IPs taucht in 0 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-26 04:21 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 9,577,670)
- seit Zyklus-Start (2026-08-23): 📈 +181,631 (Anstieg)
- letzter combined-Cleanup-Pass: 5,743 IPs durch Ablauf entfernt (davon 5,743 Watchlist/30T, 0 Active/180T), 2,486,141 neue IPs hinzugekommen (davon 1,674,856 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 97 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 189,793 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 16,106,763 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 3,724,142 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 3,724,142 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-08-25T15:52 bis 2026-08-26T02:13 UTC
