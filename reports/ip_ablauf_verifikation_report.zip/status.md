# ✅ OK

0 Rückfälle - keine der 0 eingefrorenen IPs taucht in 0 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-26 15:47 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +10,199 (Anstieg) (jetzt 9,605,118)
- seit Zyklus-Start (2026-08-23): 📈 +209,079 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 1,868,289 neue IPs hinzugekommen (davon 1,669,413 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 21 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 188,677 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 16,182,857 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 630,159 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 630,159 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-26T02:13 bis 2026-08-26T13:39 UTC
