# ✅ OK

0 Rückfälle - keine der 3,931,538 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-12 21:27 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +25,285 (Anstieg) (jetzt 11,299,112)
- seit Zyklus-Start (2026-10-22): 📈 +240,669 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 822,067 neue IPs hinzugekommen (davon 718,095 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 20 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 107,064 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,742,656 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 22,377 | gestern 23,336 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,158
  - davon Active/180 Tage: heute 20,377 | gestern 22,178
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-11T17:27 bis 2026-11-12T20:13 UTC
