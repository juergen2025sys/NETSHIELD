# ✅ OK

0 Rückfälle - keine der 1,018,465 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-13 12:49 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,790 (Anstieg) (jetzt 11,090,829)
- seit Zyklus-Start (2026-08-23): 📈 +1,694,790 (Anstieg)
- letzter combined-Cleanup-Pass: 245,406 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 245,406 Active/180T), 1,074,321 neue IPs hinzugekommen (davon 937,988 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 41 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 geschützt entfernt, 137,735 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,562,539 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,960,539 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,960,539 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-12T19:59 bis 2026-09-13T10:29 UTC
