# ✅ OK

0 Rückfälle - keine der 3,739,442 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-05 21:26 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +8,715 (Anstieg) (jetzt 11,190,160)
- seit Zyklus-Start (2026-10-22): 📈 +131,717 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 812,043 neue IPs hinzugekommen (davon 698,800 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 75 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 107,443 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,480,148 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 54,174 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 50,174 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-04T20:03 bis 2026-11-05T20:16 UTC
