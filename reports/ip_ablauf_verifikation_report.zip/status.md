# ✅ OK

0 Rückfälle - keine der 3,261,926 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-22 00:03 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +5,399 (Anstieg) (jetzt 11,082,029)
- seit Zyklus-Start (2026-09-22): 📉 -395,690 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 890,277 neue IPs hinzugekommen (davon 765,627 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 378 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 119,574 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,144,167 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 13,006 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 11,006 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-21T05:05 bis 2026-10-21T21:58 UTC
