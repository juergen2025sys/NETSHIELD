# ✅ OK

0 Rückfälle - keine der 3,801,759 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-07 02:28 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -22,538 (Rückgang) (jetzt 11,172,501)
- seit Zyklus-Start (2026-10-22): 📈 +114,058 (Anstieg)
- letzter combined-Cleanup-Pass: 26,295 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 24,295 Active/180T), 809,331 neue IPs hinzugekommen (davon 701,935 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 103 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 107,676 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,496,206 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 64,414 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 60,414 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-06T01:41 bis 2026-11-07T01:14 UTC
