# ✅ OK

0 Rückfälle - keine der 1,010,649 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-14 22:05 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,166,289)
- seit Zyklus-Start (2026-08-23): 📈 +1,770,250 (Anstieg)
- letzter combined-Cleanup-Pass: 245,038 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 245,038 Active/180T), 1,076,091 neue IPs hinzugekommen (davon 939,823 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 157 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 137,274 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,615,428 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,963,010 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,961,010 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-13T23:33 bis 2026-09-14T19:56 UTC
