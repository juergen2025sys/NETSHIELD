# ✅ OK

0 Rückfälle - keine der 3,910,676 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-11 08:23 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -2,260 (Rückgang) (jetzt 11,241,183)
- seit Zyklus-Start (2026-10-22): 📈 +182,740 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 811,975 neue IPs hinzugekommen (davon 708,271 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 51 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 110,126 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,506,939 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 24,185 | gestern 33,669 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,157
  - davon Active/180 Tage: heute 22,185 | gestern 32,512
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-10T10:22 bis 2026-11-11T07:10 UTC
