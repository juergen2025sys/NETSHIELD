# ✅ OK

0 Rückfälle - keine der 1,010,868 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-14 09:53 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +8,603 (Anstieg) (jetzt 11,125,038)
- seit Zyklus-Start (2026-08-23): 📈 +1,728,999 (Anstieg)
- letzter combined-Cleanup-Pass: 245,379 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 245,379 Active/180T), 1,084,102 neue IPs hinzugekommen (davon 937,730 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 291 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 geschützt entfernt, 139,439 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,605,121 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,962,484 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,960,484 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-13T16:07 bis 2026-09-14T06:42 UTC
