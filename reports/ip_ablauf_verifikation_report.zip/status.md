# ✅ OK

0 Rückfälle - keine der 3,338,206 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-23 07:36 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -29,870 (Rückgang) (jetzt 11,088,422)
- seit Zyklus-Start (2026-10-22): 📈 +29,979 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 896,832 neue IPs hinzugekommen (davon 761,687 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 2,983 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 124,718 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,137,019 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 32,437 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 30,437 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-22T11:38 bis 2026-10-23T05:24 UTC
