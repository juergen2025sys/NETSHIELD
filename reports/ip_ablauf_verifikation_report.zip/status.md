# ✅ OK

0 Rückfälle - keine der 1,020,300 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-12 01:44 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,009,397)
- seit Zyklus-Start (2026-08-23): 📈 +1,613,358 (Anstieg)
- letzter combined-Cleanup-Pass: 245,490 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 245,490 Active/180T), 1,073,374 neue IPs hinzugekommen (davon 939,831 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 6 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 geschützt entfernt, 136,139 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,701,085 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,961,095 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,961,095 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-11T11:38 bis 2026-09-11T23:31 UTC
