# ✅ OK

0 Rückfälle - keine der 360,096 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-07 21:30 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +23,482 (Anstieg) (jetzt 11,214,280)
- seit Zyklus-Start (2026-08-23): 📈 +1,818,241 (Anstieg)
- letzter combined-Cleanup-Pass: 155,446 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,446 Active/180T), 1,029,027 neue IPs hinzugekommen (davon 830,036 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 395 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 189,676 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,063,644 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,245,348 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,243,348 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-06T22:56 bis 2026-09-07T19:22 UTC
