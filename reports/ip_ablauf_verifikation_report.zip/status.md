# ✅ OK

0 Rückfälle - keine der 197,970 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-30 08:07 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +8,308 (Anstieg) (jetzt 9,540,902)
- seit Zyklus-Start (2026-08-23): 📈 +144,863 (Anstieg)
- letzter combined-Cleanup-Pass: 171,840 IPs durch Ablauf entfernt (davon 171,840 Watchlist/30T, 0 Active/180T), 1,861,539 neue IPs hinzugekommen (davon 1,684,777 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 3,968 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 190,435 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,874,119 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,322,795 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 1,322,795 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-29T14:41 bis 2026-08-30T05:51 UTC
