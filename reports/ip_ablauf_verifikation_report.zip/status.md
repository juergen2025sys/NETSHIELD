# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 2 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-08-31 02:26 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 9,589,730)
- seit Zyklus-Start (2026-08-23): 📈 +193,691 (Anstieg)
- letzter combined-Cleanup-Pass: 171,496 IPs durch Ablauf entfernt (davon 171,496 Watchlist/30T, 0 Active/180T), 1,807,647 neue IPs hinzugekommen (davon 1,635,511 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 15 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 190,286 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,832,503 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,427,215 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 1,427,215 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-30T07:13 bis 2026-08-30T23:54 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| active_blacklist_ipv4.txt | 2 | 122.183.40.107, 137.184.125.181 |
| combined_threat_blacklist_ipv4_part2.txt | 2 | 122.183.40.107, 137.184.125.181 |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
