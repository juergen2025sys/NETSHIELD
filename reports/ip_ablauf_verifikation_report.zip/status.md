# ✅ OK

0 Rückfälle - keine der 1,018,229 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-14 01:49 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,106,292)
- seit Zyklus-Start (2026-08-23): 📈 +1,710,253 (Anstieg)
- letzter combined-Cleanup-Pass: 244,872 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,872 Active/180T), 1,073,557 neue IPs hinzugekommen (davon 935,968 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 1 geschützt entfernt, 139,099 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,585,620 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,959,986 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,959,986 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-13T11:39 bis 2026-09-13T23:33 UTC
