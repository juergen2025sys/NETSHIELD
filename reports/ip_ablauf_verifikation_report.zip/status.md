# ✅ OK

0 Rückfälle - keine der 4,335,184 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-22 02:35 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -25,630 (Rückgang) (jetzt 11,236,169)
- seit Zyklus-Start (2026-11-21): 📉 -36,041 (Rückgang)
- letzter combined-Cleanup-Pass: 32,221 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 30,221 Active/180T), 905,074 neue IPs hinzugekommen (davon 791,927 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 69 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 110,225 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,027,183 (Summe 7 verschiedene Combined-Läufe in den letzten 7 Prüfläufen / 7 Lauf(e), noch keine 24h Historie seit Zyklus-Start; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 32,221 | gestern 62,183 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,117
  - davon Active/180 Tage: heute 30,221 | gestern 61,066
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-11-21T02:50 bis 2026-11-22T01:27 UTC
