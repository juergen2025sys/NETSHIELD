# ✅ OK

0 Rückfälle - keine der 1,410,512 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-11 21:49 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,880 (Anstieg) (jetzt 12,308,165)
- seit Zyklus-Start (2026-09-22): 📈 +830,446 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 895,031 neue IPs hinzugekommen (davon 770,493 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 110 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 117,927 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,193,071 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 17,987 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 15,987 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-10T19:32 bis 2026-10-11T19:43 UTC
