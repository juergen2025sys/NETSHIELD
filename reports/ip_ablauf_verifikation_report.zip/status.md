# ✅ OK

0 Rückfälle - keine der 1,020,894 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-10 23:20 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,782 (Anstieg) (jetzt 10,886,561)
- seit Zyklus-Start (2026-08-23): 📈 +1,490,522 (Anstieg)
- letzter combined-Cleanup-Pass: 291,306 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 291,306 Active/180T), 1,134,844 neue IPs hinzugekommen (davon 941,903 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 49 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 195,530 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,016,850 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,335,390 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,333,390 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-10T04:59 bis 2026-09-10T21:12 UTC
