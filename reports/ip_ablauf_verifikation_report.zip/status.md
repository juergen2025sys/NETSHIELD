# ✅ OK

0 Rückfälle - keine der 1,010,944 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-14 03:34 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +574 (Anstieg) (jetzt 11,106,866)
- seit Zyklus-Start (2026-08-23): 📈 +1,710,827 (Anstieg)
- letzter combined-Cleanup-Pass: 247,404 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 245,404 Active/180T), 1,072,659 neue IPs hinzugekommen (davon 935,493 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 8 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 geschützt entfernt, 139,820 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,583,958 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,961,984 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,959,984 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-13T12:10 bis 2026-09-14T00:28 UTC
