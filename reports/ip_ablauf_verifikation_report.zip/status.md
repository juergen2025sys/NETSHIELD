# ✅ OK

0 Rückfälle - keine der 869,952 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-24 07:42 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -6,603 (Rückgang) (jetzt 11,607,045)
- seit Zyklus-Start (2026-09-22): 📈 +129,326 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 940,530 neue IPs hinzugekommen (davon 806,514 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 250 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 125,498 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,624,469 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 15,041 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 13,041 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-23T15:13 bis 2026-09-24T05:27 UTC
