# ✅ OK

0 Rückfälle - keine der 853,679 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-23 07:24 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -1,306 (Rückgang) (jetzt 11,535,965)
- seit Zyklus-Start (2026-09-22): 📈 +58,246 (Anstieg)
- letzter combined-Cleanup-Pass: 15,041 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 13,041 Active/180T), 975,510 neue IPs hinzugekommen (davon 834,073 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 5,301 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 127,937 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,687,325 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 15,041 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 13,041 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-22T11:25 bis 2026-09-23T05:12 UTC
