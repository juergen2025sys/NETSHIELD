# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 35410 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-08-25 06:31 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 8,936,454)
- seit Zyklus-Start (2026-08-23): 📉 -459,585 (Rückgang)
- letzter combined-Cleanup-Pass: 619,112 IPs durch Ablauf entfernt (davon 619,112 Watchlist/30T, 0 Active/180T), 1,863,082 neue IPs hinzugekommen (davon 1,671,368 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 417 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 187,329 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,879,897 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 4,963,438 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,963,438 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-08-24T19:17 bis 2026-08-25T04:23 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| active_blacklist_ipv4.txt | 35410 | 1.0.218.230, 1.1.202.148, 1.11.62.185, 1.11.62.186, 1.116.214.66, ... |
| combined_threat_blacklist_ipv4_part1.txt | 12671 | 1.0.218.230, 1.1.202.148, 1.11.62.185, 1.11.62.186, 1.116.214.66, ... |
| combined_threat_blacklist_ipv4_part2.txt | 22739 | 112.245.55.60, 112.245.59.63, 112.250.110.172, 112.252.132.185, 113.100.186.171, ... |
| blacklist_confidence40_ipv4_part1.txt | 35410 | 1.0.218.230, 1.1.202.148, 1.11.62.185, 1.11.62.186, 1.116.214.66, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
