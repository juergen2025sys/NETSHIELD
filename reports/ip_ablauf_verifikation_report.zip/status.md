# ✅ OK

0 Rückfälle - keine der 836,046 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-17 19:23 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,400,539)
- seit Zyklus-Start (2026-08-23): 📈 +2,004,500 (Anstieg)
- letzter combined-Cleanup-Pass: 244,130 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,130 Active/180T), 1,082,209 neue IPs hinzugekommen (davon 933,681 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 138 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 134,923 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,620,206 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,955,534 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,953,534 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-16T21:29 bis 2026-09-17T17:16 UTC
