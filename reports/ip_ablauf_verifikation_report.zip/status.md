# ✅ OK

0 Rückfälle - keine der 186,490 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-02 01:42 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,089,134)
- seit Zyklus-Start (2026-08-23): 📈 +1,693,095 (Anstieg)
- letzter combined-Cleanup-Pass: 2,000 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 0 Active/180T), 545,252 neue IPs hinzugekommen (davon 404,991 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 15 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 142,835 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 11,926,757 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 8,000 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 8,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-01T08:54 bis 2026-09-01T23:33 UTC
