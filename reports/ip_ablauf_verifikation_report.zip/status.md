# ✅ OK

0 Rückfälle - keine der 3,377,444 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-24 13:44 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +15,018 (Anstieg) (jetzt 11,115,691)
- seit Zyklus-Start (2026-10-22): 📈 +57,248 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 887,340 neue IPs hinzugekommen (davon 758,093 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 2,975 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 121,895 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,100,780 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 43,535 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 41,535 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-23T16:56 bis 2026-10-24T11:39 UTC
