# ✅ OK

0 Rückfälle - keine der 3,624,664 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-01 23:33 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,500 (Anstieg) (jetzt 11,179,558)
- seit Zyklus-Start (2026-10-22): 📈 +121,115 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 821,762 neue IPs hinzugekommen (davon 697,124 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 156 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,319 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,798,133 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 29,681 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 27,681 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-01T00:01 bis 2026-11-01T22:26 UTC
