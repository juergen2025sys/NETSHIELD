# ✅ OK

0 Rückfälle - keine der 890,558 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-25 06:42 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -9,162 (Rückgang) (jetzt 11,640,965)
- seit Zyklus-Start (2026-09-22): 📈 +163,246 (Anstieg)
- letzter combined-Cleanup-Pass: 22,902 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 20,902 Active/180T), 967,763 neue IPs hinzugekommen (davon 827,304 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 25 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 126,917 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,648,276 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 22,902 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 20,902 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-24T10:24 bis 2026-09-25T00:56 UTC
