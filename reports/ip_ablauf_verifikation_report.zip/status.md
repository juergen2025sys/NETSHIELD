# ✅ OK

0 Rückfälle - keine der 907,583 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-26 07:43 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +9,657 (Anstieg) (jetzt 11,697,517)
- seit Zyklus-Start (2026-09-22): 📈 +219,798 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 961,772 neue IPs hinzugekommen (davon 832,150 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 5,691 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,132 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,644,143 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 19,408 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 17,408 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-25T08:16 bis 2026-09-26T05:31 UTC
