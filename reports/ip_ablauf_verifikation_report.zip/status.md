# ✅ OK

0 Rückfälle - keine der 0 eingefrorenen IPs taucht in 0 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-26 12:27 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,194 (Anstieg) (jetzt 9,594,919)
- seit Zyklus-Start (2026-08-23): 📈 +198,880 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 1,868,818 neue IPs hinzugekommen (davon 1,675,963 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 20 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 189,661 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 16,180,434 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,248,860 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 1,248,860 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-26T00:44 bis 2026-08-26T10:17 UTC
