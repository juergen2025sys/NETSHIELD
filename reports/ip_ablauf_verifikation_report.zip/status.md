# ✅ OK

0 Rückfälle - keine der 4,046,168 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-18 11:42 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +8,140 (Anstieg) (jetzt 11,378,459)
- seit Zyklus-Start (2026-10-22): 📈 +320,016 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 826,224 neue IPs hinzugekommen (davon 713,471 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 184 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 109,243 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,601,274 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 21,380 | gestern 17,140 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 19,380 | gestern 15,140
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-17T03:41 bis 2026-11-18T10:36 UTC
