# ✅ OK

0 Rückfälle - keine der 836,564 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-16 11:53 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,217 (Anstieg) (jetzt 11,317,217)
- seit Zyklus-Start (2026-08-23): 📈 +1,921,178 (Anstieg)
- letzter combined-Cleanup-Pass: 244,643 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,643 Active/180T), 1,079,866 neue IPs hinzugekommen (davon 934,717 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 407 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 Whitelist-Bereinigung, 139,239 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,534,647 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,958,977 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,956,977 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-15T11:57 bis 2026-09-16T05:48 UTC
