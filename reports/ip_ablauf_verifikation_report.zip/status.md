# ✅ OK

0 Rückfälle - keine der 853,657 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-23 11:33 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +10,011 (Anstieg) (jetzt 11,545,976)
- seit Zyklus-Start (2026-09-22): 📈 +68,257 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 966,314 neue IPs hinzugekommen (davon 833,350 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 1,233 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 Whitelist-Bereinigung, 125,159 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,694,808 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 15,041 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 13,041 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-22T11:54 bis 2026-09-23T06:20 UTC
