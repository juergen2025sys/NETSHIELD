# ✅ OK

0 Rückfälle - keine der 3,262,145 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-21 06:28 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -2,574 (Rückgang) (jetzt 11,013,636)
- seit Zyklus-Start (2026-09-22): 📉 -464,083 (Rückgang)
- letzter combined-Cleanup-Pass: 13,006 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 11,006 Active/180T), 888,207 neue IPs hinzugekommen (davon 763,116 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 154 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 120,121 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,125,625 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 13,006 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 11,006 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-20T06:34 bis 2026-10-20T23:59 UTC
