# ✅ OK

0 Rückfälle - keine der 835,528 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-19 07:00 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +14,182 (Anstieg) (jetzt 11,508,382)
- seit Zyklus-Start (2026-08-23): 📈 +2,112,343 (Anstieg)
- letzter combined-Cleanup-Pass: 243,891 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,891 Active/180T), 1,078,585 neue IPs hinzugekommen (davon 937,093 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 4,424 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 133,645 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,556,088 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,951,734 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,951,734 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-18T16:18 bis 2026-09-19T04:49 UTC
