# ✅ OK

0 Rückfälle - keine der 1,339,327 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-09 03:35 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 12,179,127)
- seit Zyklus-Start (2026-09-22): 📈 +701,408 (Anstieg)
- letzter combined-Cleanup-Pass: 222,625 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 220,625 Active/180T), 920,136 neue IPs hinzugekommen (davon 785,979 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 199 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 125,498 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,337,278 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 445,250 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 441,250 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-08T04:12 bis 2026-10-09T01:27 UTC
