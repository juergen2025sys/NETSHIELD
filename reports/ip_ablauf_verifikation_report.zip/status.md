# ✅ OK

0 Rückfälle - keine der 922,469 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-27 19:23 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +9,138 (Anstieg) (jetzt 11,794,994)
- seit Zyklus-Start (2026-09-22): 📈 +317,275 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 937,237 neue IPs hinzugekommen (davon 806,338 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 238 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,053 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,469,565 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 16,988 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 14,988 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-26T21:35 bis 2026-09-27T17:22 UTC
