# ✅ OK

0 Rückfälle - keine der 3,377,537 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-24 03:58 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -34,720 (Rückgang) (jetzt 11,091,073)
- seit Zyklus-Start (2026-10-22): 📈 +32,630 (Anstieg)
- letzter combined-Cleanup-Pass: 43,535 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 41,535 Active/180T), 889,360 neue IPs hinzugekommen (davon 757,858 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 85 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 123,012 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,104,062 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 43,535 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 41,535 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-23T05:07 bis 2026-10-24T00:02 UTC
