# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 176424 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-09-02 07:18 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,164 (Anstieg) (jetzt 11,096,250)
- seit Zyklus-Start (2026-08-23): 📈 +1,700,211 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 1,023,829 neue IPs hinzugekommen (davon 827,952 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 222 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 197,271 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,945,369 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-01T14:13 bis 2026-09-02T05:05 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| active_blacklist_ipv4.txt | 102 | 101.53.250.20, 103.160.234.194, 103.182.69.27, 103.82.252.62, 104.207.57.110, ... |
| combined_threat_blacklist_ipv4_part1.txt | 83234 | 1.0.137.182, 1.1.176.123, 1.1.197.87, 1.1.221.157, 1.1.245.219, ... |
| combined_threat_blacklist_ipv4_part2.txt | 93190 | 112.132.172.196, 112.132.212.252, 112.132.249.126, 112.133.195.17, 112.133.195.52, ... |
| blacklist_confidence40_ipv4_part1.txt | 102 | 101.53.250.20, 103.160.234.194, 103.182.69.27, 103.82.252.62, 104.207.57.110, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
