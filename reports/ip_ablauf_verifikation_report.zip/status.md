# ✅ OK

0 Rückfälle - keine der 3,951,781 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-13 21:12 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +4,828 (Anstieg) (jetzt 11,330,730)
- seit Zyklus-Start (2026-10-22): 📈 +272,287 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 820,870 neue IPs hinzugekommen (davon 710,928 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 9 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 106,204 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,933,638 (Summe 6 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 21,521 | gestern 22,374 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 19,521 | gestern 20,374
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-13T00:50 bis 2026-11-13T20:03 UTC
