# ✅ OK

0 Rückfälle - keine der 360,142 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-05 14:43 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,039,912)
- seit Zyklus-Start (2026-08-23): 📈 +1,643,873 (Anstieg)
- letzter combined-Cleanup-Pass: 155,448 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,448 Active/180T), 1,016,725 neue IPs hinzugekommen (davon 832,534 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 10 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 186,856 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,143,163 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,108,354 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,106,354 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-04T20:41 bis 2026-09-05T10:55 UTC
