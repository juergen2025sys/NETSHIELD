# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 20377 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-11-12 02:12 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -18,135 (Rückgang) (jetzt 11,256,860)
- seit Zyklus-Start (2026-10-22): 📈 +198,417 (Anstieg)
- letzter combined-Cleanup-Pass: 22,377 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 20,377 Active/180T), 817,804 neue IPs hinzugekommen (davon 716,199 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 14 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 107,010 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,534,575 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 22,377 | gestern 23,340 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,158
  - davon Active/180 Tage: heute 20,377 | gestern 22,182
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-10T23:36 bis 2026-11-12T01:00 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| blacklist_confidence40_ipv4_part1.txt | 15933 | 1.0.158.241, 1.0.173.196, 1.0.174.179, 1.0.229.165, 1.0.248.165, ... |
| blacklist_confidence40_ipv4_part2.txt | 4444 | 3.15.42.78, 3.16.165.212, 3.19.75.147, 3.236.170.6, 3.248.208.229, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
