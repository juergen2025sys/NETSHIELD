# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 2 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-08-31 16:41 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 9,607,940)
- seit Zyklus-Start (2026-08-23): 📈 +211,901 (Anstieg)
- letzter combined-Cleanup-Pass: 176,555 IPs durch Ablauf entfernt (davon 176,555 Watchlist/30T, 0 Active/180T), 1,768,569 neue IPs hinzugekommen (davon 1,635,807 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 95 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 143,555 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,681,806 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,448,062 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 1,448,062 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-30T18:36 bis 2026-08-31T14:26 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| active_blacklist_ipv4.txt | 2 | 122.183.40.107, 137.184.125.181 |
| combined_threat_blacklist_ipv4_part2.txt | 2 | 122.183.40.107, 137.184.125.181 |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
