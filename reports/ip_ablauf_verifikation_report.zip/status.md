# ✅ OK

0 Rückfälle - keine der 840,626 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-15 19:25 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +15,663 (Anstieg) (jetzt 11,266,947)
- seit Zyklus-Start (2026-08-23): 📈 +1,870,908 (Anstieg)
- letzter combined-Cleanup-Pass: 244,715 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,715 Active/180T), 1,083,221 neue IPs hinzugekommen (davon 933,552 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 150 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 134,297 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,659,296 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,961,334 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,959,334 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-14T21:46 bis 2026-09-15T17:17 UTC
