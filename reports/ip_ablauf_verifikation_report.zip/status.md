# ✅ OK

0 Rückfälle - keine der 3,828,559 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-08 08:33 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,181,721)
- seit Zyklus-Start (2026-10-22): 📈 +123,278 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 819,586 neue IPs hinzugekommen (davon 707,186 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 5,045 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 109,774 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,055,944 (Summe 5 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 27,968 | gestern 26,291 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 25,968 | gestern 24,291
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-07T01:14 bis 2026-11-08T06:43 UTC
