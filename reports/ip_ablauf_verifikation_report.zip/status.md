# ✅ OK

0 Rückfälle - keine der 1,021,991 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-08 21:37 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +15,043 (Anstieg) (jetzt 10,777,942)
- seit Zyklus-Start (2026-08-23): 📈 +1,381,903 (Anstieg)
- letzter combined-Cleanup-Pass: 292,295 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 292,295 Active/180T), 1,128,374 neue IPs hinzugekommen (davon 939,650 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 6 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 191,445 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,009,057 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,065,817 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,065,817 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-08T04:23 bis 2026-09-08T18:59 UTC
