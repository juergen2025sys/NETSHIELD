# ✅ OK

0 Rückfälle - keine der 840,776 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-22 23:14 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,180 (Anstieg) (jetzt 11,528,125)
- seit Zyklus-Start (2026-09-22): 📈 +50,406 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 957,525 neue IPs hinzugekommen (davon 830,891 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 222 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 123,694 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,689,327 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 16,860 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 12,860 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-22T04:41 bis 2026-09-22T21:12 UTC
