# ✅ OK

0 Rückfälle - keine der 3,094,421 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-14 14:35 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +24,483 (Anstieg) (jetzt 10,795,874)
- seit Zyklus-Start (2026-09-22): 📉 -681,845 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 892,452 neue IPs hinzugekommen (davon 764,395 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 105 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,092 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,035,741 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 69,800 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 65,800 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-13T15:06 bis 2026-10-14T12:24 UTC
