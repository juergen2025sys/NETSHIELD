# ✅ OK

0 Rückfälle - keine der 934,121 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-28 07:09 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -8,090 (Rückgang) (jetzt 11,794,876)
- seit Zyklus-Start (2026-09-22): 📈 +317,157 (Anstieg)
- letzter combined-Cleanup-Pass: 13,588 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 11,588 Active/180T), 925,766 neue IPs hinzugekommen (davon 795,328 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 278 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 125,223 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,424,208 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 13,588 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 11,588 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-27T05:29 bis 2026-09-27T23:58 UTC
