# ✅ OK

0 Rückfälle - keine der 840,969 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-22 07:40 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +16,163 (Anstieg) (jetzt 11,493,882)
- seit Zyklus-Start (2026-09-22): 📈 +16,163 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 969,451 neue IPs hinzugekommen (davon 827,305 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 147 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 128,220 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 2,894,737 (Summe letzte 3 Läufe / 3 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- entfernte IPs (Summe letzter Läufe): 16,860 (Summe letzte 3 Läufe / 3 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 3 Läufe / 3 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Active/180 Tage: 12,860 (Summe letzte 3 Läufe / 3 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-21T13:05 bis 2026-09-22T05:37 UTC
