# ❌ ALARM

**3 Problem(e) erkannt:**

- ❌ **Rückfall:** 62668 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.
- ⚠️ **Niedrige combined-Erfolgsquote:** nur 6/15 erfolgreich (40%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-08-24T03:32 bis 2026-08-24T10:21 UTC in den letzten 16 Läufen (Schwelle: 75%, cancelled nicht mitgezaehlt) - auch wenn der neueste Stand frisch wirkt, lief das System zuletzt nicht zuverlässig.
- ⚠️ **Veraltete Daten:** `state/seen_db_meta.json` ist 6.3h alt (Schwelle: 6h). `update_combined_blacklist.yml` (Cron alle 3h) läuft möglicherweise nicht mehr planmäßig - alle Aussagen dieses Berichts basieren auf diesem veralteten Stand.

Lauf: 2026-08-24 12:48 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 8,772,949)
- seit Zyklus-Start (2026-08-23): 📉 -623,090 (Rückgang)
- letzter combined-Cleanup-Pass: 657,370 IPs durch Ablauf entfernt (davon 657,370 Watchlist/30T, 0 Active/180T), 1,968,228 neue IPs hinzugekommen (davon 1,767,036 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 187,059 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 15,745,361 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 5,258,962 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 5,258,962 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 🔍 6/15 erfolgreich (40%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-08-24T03:32 bis 2026-08-24T10:21 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| bot_detector_blacklist_ipv4.txt | 29527 | 1.0.0.104, 1.0.171.2, 1.0.215.7, 1.0.227.38, 1.1.187.152, ... |
| honeypot_ips.txt | 34717 | 1.0.218.230, 1.1.202.148, 1.11.62.185, 1.11.62.186, 1.116.214.66, ... |
| honigtopf_ips.txt | 12 | 111.250.240.29, 122.97.137.17, 129.226.193.45, 147.182.205.127, 157.245.152.222, ... |
| tweetfeed_ips.txt | 64 | 1.0.2.0, 103.214.172.14, 115.226.251.119, 123.5.149.113, 13.140.8.25, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
