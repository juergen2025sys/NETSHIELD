# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 15987 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-10-11 02:36 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,032 (Anstieg) (jetzt 12,271,665)
- seit Zyklus-Start (2026-09-22): 📈 +793,946 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 894,136 neue IPs hinzugekommen (davon 770,121 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 253 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 118,261 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,269,356 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 0 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-10-09T22:49 bis 2026-10-11T00:30 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| combined_threat_blacklist_ipv4_part1.txt | 4590 | 1.117.72.154, 1.12.240.23, 1.162.112.3, 1.164.122.183, 1.164.245.237, ... |
| combined_threat_blacklist_ipv4_part2.txt | 11397 | 112.248.116.161, 113.0.241.31, 113.109.122.83, 113.109.197.142, 113.110.254.52, ... |
| blacklist_confidence40_ipv4_part1.txt | 8720 | 1.117.72.154, 1.12.240.23, 1.162.112.3, 1.164.122.183, 1.164.245.237, ... |
| blacklist_confidence40_ipv4_part2.txt | 7267 | 13.217.145.147, 13.221.218.208, 13.221.98.163, 13.40.125.247, 13.71.169.84, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
