# ✅ OK

0 Rückfälle - keine der 360,136 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-05 19:49 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,199 (Anstieg) (jetzt 11,051,745)
- seit Zyklus-Start (2026-08-23): 📈 +1,655,706 (Anstieg)
- letzter combined-Cleanup-Pass: 155,502 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,502 Active/180T), 1,015,668 neue IPs hinzugekommen (davon 830,213 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 54 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 186,578 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,140,868 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,243,695 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,243,695 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-05T00:37 bis 2026-09-05T17:40 UTC
