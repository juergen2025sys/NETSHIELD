# ❌ ALARM

**1 Problem(e) erkannt:**

- ⚠️ **Niedrige combined-Erfolgsquote:** nur 10/16 erfolgreich (62%), Zeitraum 2026-08-23T07:20 bis 2026-08-23T15:58 UTC in den letzten 16 Läufen (Schwelle: 75%) - auch wenn der neueste Stand frisch wirkt, lief das System zuletzt nicht zuverlässig.

Lauf: 2026-08-23 18:34 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 9,406,053)
- seit Zyklus-Start (2026-08-23): 📈 +10,014 (Anstieg)
- letzter combined-Cleanup-Pass: n/a (kein combined-Lauf mit Cleanup-Statistik gefunden)
- neue IPs (Summe letzter Läufe): n/a (0/8 Läufe im Fenster mit Daten)
- entfernte IPs (Summe letzter Läufe): n/a (0/8 Läufe im Fenster mit Daten)
- Erfolgsquote letzte 16 combined-Läufe: 🔍 10/16 erfolgreich (62%), Zeitraum 2026-08-23T07:20 bis 2026-08-23T15:58 UTC

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
