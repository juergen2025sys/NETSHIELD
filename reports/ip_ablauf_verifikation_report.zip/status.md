# ✅ OK

0 Rückfälle - keine der 1,021,732 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-09 14:04 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +10,966 (Anstieg) (jetzt 10,822,006)
- seit Zyklus-Start (2026-08-23): 📈 +1,425,967 (Anstieg)
- letzter combined-Cleanup-Pass: 292,594 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 292,594 Active/180T), 1,135,337 neue IPs hinzugekommen (davon 940,971 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 465 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 190,794 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,088,415 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,340,972 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,338,972 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-08T21:08 bis 2026-09-09T11:53 UTC
