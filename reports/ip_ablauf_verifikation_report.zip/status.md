# ✅ OK

0 Rückfälle - keine der 835,698 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-18 23:22 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +1,645 (Anstieg) (jetzt 11,485,563)
- seit Zyklus-Start (2026-08-23): 📈 +2,089,524 (Anstieg)
- letzter combined-Cleanup-Pass: 243,967 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,967 Active/180T), 1,063,582 neue IPs hinzugekommen (davon 931,730 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 130,490 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,548,315 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,954,202 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,952,202 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-18T11:04 bis 2026-09-18T21:15 UTC
