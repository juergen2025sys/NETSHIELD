# ✅ OK

0 Rückfälle - keine der 1,010,548 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-15 02:06 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,183,419)
- seit Zyklus-Start (2026-08-23): 📈 +1,787,380 (Anstieg)
- letzter combined-Cleanup-Pass: 245,034 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 245,034 Active/180T), 1,089,027 neue IPs hinzugekommen (davon 936,341 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 157 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 137,223 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,646,368 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,963,334 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,961,334 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-14T05:27 bis 2026-09-14T23:59 UTC
