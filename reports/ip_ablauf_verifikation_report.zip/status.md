# ✅ OK

0 Rückfälle - keine der 627,078 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-25 09:27 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +5,886 (Anstieg) (jetzt 8,942,684)
- seit Zyklus-Start (2026-08-23): 📉 -453,355 (Rückgang)
- letzter combined-Cleanup-Pass: 619,070 IPs durch Ablauf entfernt (davon 619,070 Watchlist/30T, 0 Active/180T), 1,861,909 neue IPs hinzugekommen (davon 1,672,743 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 1,853 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 187,729 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,880,265 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 4,967,971 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,967,971 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-24T21:37 bis 2026-08-25T07:23 UTC
