# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 308 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-09-07 06:19 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +4,867 (Anstieg) (jetzt 11,163,016)
- seit Zyklus-Start (2026-08-23): 📈 +1,766,977 (Anstieg)
- letzter combined-Cleanup-Pass: 157,400 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 155,400 Active/180T), 1,018,253 neue IPs hinzugekommen (davon 825,970 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 34 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 189,668 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,171,165 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,245,250 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,243,250 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-06T10:47 bis 2026-09-07T00:40 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| active_blacklist_ipv4.txt | 308 | 101.53.250.20, 102.129.153.207, 102.129.56.183, 102.165.52.148, 102.64.41.246, ... |
| combined_threat_blacklist_ipv4_part1.txt | 145 | 101.53.250.20, 102.129.153.207, 102.129.56.183, 102.165.52.148, 102.64.41.246, ... |
| combined_threat_blacklist_ipv4_part2.txt | 163 | 112.104.64.155, 113.161.44.1, 113.23.35.151, 113.57.184.205, 115.186.103.226, ... |
| blacklist_confidence40_ipv4_part1.txt | 308 | 101.53.250.20, 102.129.153.207, 102.129.56.183, 102.165.52.148, 102.64.41.246, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
