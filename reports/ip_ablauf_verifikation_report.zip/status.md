# ✅ OK

0 Rückfälle - keine der 853,508 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-23 16:29 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +34,500 (Anstieg) (jetzt 11,594,263)
- seit Zyklus-Start (2026-09-22): 📈 +116,544 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 977,751 neue IPs hinzugekommen (davon 818,445 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 1 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 125,020 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,720,767 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 15,041 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 13,041 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-22T17:18 bis 2026-09-23T12:27 UTC
