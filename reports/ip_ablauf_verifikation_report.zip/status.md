# ✅ OK

0 Rückfälle - keine der 627,030 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-25 15:42 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,798 (Anstieg) (jetzt 8,947,997)
- seit Zyklus-Start (2026-08-23): 📉 -448,042 (Rückgang)
- letzter combined-Cleanup-Pass: 618,737 IPs durch Ablauf entfernt (davon 618,737 Watchlist/30T, 0 Active/180T), 1,862,445 neue IPs hinzugekommen (davon 1,674,602 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 11 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 188,520 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,843,583 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 4,957,877 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,957,877 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-25T03:27 bis 2026-08-25T13:35 UTC
