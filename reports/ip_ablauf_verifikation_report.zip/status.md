# ✅ OK

0 Rückfälle - keine der 1,020,494 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-11 15:49 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 10,992,609)
- seit Zyklus-Start (2026-08-23): 📈 +1,596,570 (Anstieg)
- letzter combined-Cleanup-Pass: 245,552 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 245,552 Active/180T), 1,079,268 neue IPs hinzugekommen (davon 939,279 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 12 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 geschützt entfernt, 138,665 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,063,734 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,139,460 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,137,460 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-10T21:12 bis 2026-09-11T11:49 UTC
