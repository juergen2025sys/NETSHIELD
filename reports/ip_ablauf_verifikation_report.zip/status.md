# ✅ OK

0 Rückfälle - keine der 3,776,606 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-06 02:56 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -33,440 (Rückgang) (jetzt 11,160,395)
- seit Zyklus-Start (2026-10-22): 📈 +101,952 (Anstieg)
- letzter combined-Cleanup-Pass: 38,119 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 36,119 Active/180T), 810,162 neue IPs hinzugekommen (davon 699,069 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 20 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 110,777 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,472,312 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 92,293 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 6,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 86,293 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-05T03:46 bis 2026-11-06T01:48 UTC
