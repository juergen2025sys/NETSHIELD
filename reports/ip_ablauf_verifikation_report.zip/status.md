# ✅ OK

0 Rückfälle - keine der 1,021,605 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-09 18:56 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +7,709 (Anstieg) (jetzt 10,829,715)
- seit Zyklus-Start (2026-08-23): 📈 +1,433,676 (Anstieg)
- letzter combined-Cleanup-Pass: 292,400 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 292,400 Active/180T), 1,126,480 neue IPs hinzugekommen (davon 940,252 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 3 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 189,207 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,072,458 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,341,065 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,339,065 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-08T23:39 bis 2026-09-09T16:53 UTC
