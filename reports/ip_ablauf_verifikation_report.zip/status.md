# ✅ OK

0 Rückfälle - keine der 3,910,397 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-12 00:01 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +8,043 (Anstieg) (jetzt 11,274,995)
- seit Zyklus-Start (2026-10-22): 📈 +216,552 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 819,567 neue IPs hinzugekommen (davon 716,172 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 56 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 107,661 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,535,086 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 0 | gestern 24,182 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 0 | gestern 2,000
  - davon Active/180 Tage: heute 0 | gestern 22,182
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-10T19:37 bis 2026-11-11T22:19 UTC
