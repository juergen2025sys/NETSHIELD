# ✅ OK

0 Rückfälle - keine der 835,884 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-18 07:25 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +14,587 (Anstieg) (jetzt 11,434,033)
- seit Zyklus-Start (2026-08-23): 📈 +2,037,994 (Anstieg)
- letzter combined-Cleanup-Pass: 244,093 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,093 Active/180T), 1,080,196 neue IPs hinzugekommen (davon 931,734 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 75 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 136,151 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,594,815 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,955,004 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,953,004 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 14/14 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 2 cancelled (nicht gewertet), Zeitraum 2026-09-17T11:55 bis 2026-09-18T05:14 UTC
