# ✅ OK

0 Rückfälle - keine der 978,619 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-02 04:34 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +5,114 (Anstieg) (jetzt 12,035,157)
- seit Zyklus-Start (2026-09-22): 📈 +557,438 (Anstieg)
- letzter combined-Cleanup-Pass: 9,683 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 7,683 Active/180T), 919,091 neue IPs hinzugekommen (davon 790,287 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 21 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,147 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,365,899 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 9,683 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 7,683 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-01T08:55 bis 2026-10-02T00:58 UTC
