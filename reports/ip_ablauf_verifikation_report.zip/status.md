# ✅ OK

0 Rückfälle - keine der 4,334,850 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-23 00:34 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,963 (Anstieg) (jetzt 11,269,172)
- seit Zyklus-Start (2026-11-21): 📉 -3,038 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 900,641 neue IPs hinzugekommen (davon 793,173 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 83 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 105,211 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,323,025 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 0 | gestern 32,215 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 0 | gestern 2,000
  - davon Active/180 Tage: heute 0 | gestern 30,215
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-21T21:58 bis 2026-11-22T22:13 UTC
