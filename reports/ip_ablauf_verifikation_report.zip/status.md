# ✅ OK

0 Rückfälle - keine der 4,305,237 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-21 03:56 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -58,592 (Rückgang) (jetzt 11,213,618)
- seit Zyklus-Start (2026-11-21): 📉 -58,592 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 827,543 neue IPs hinzugekommen (davon 714,051 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 112,895 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 1,650,531 (Summe 2 verschiedene Combined-Läufe in den letzten 2 Prüfläufen / 2 Lauf(e), noch keine 24h Historie seit Zyklus-Start; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 63,068 | gestern 27,157 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,178
  - davon Active/180 Tage: heute 61,068 | gestern 25,979
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-20T11:19 bis 2026-11-21T02:50 UTC
