# ✅ OK

0 Rückfälle - keine der 0 eingefrorenen IPs taucht in 0 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-28 20:31 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +22,373 (Anstieg) (jetzt 9,688,653)
- seit Zyklus-Start (2026-08-23): 📈 +292,614 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 1,864,423 neue IPs hinzugekommen (davon 1,667,478 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 45 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 192,534 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
- entfernte IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
  - davon Watchlist/30 Tage: n/a (7/8 Läufe im Fenster mit Daten)
  - davon Active/180 Tage: n/a (7/8 Läufe im Fenster mit Daten)
- Erfolgsquote letzte 16 combined-Läufe: 12/13 erfolgreich (92%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 2 cancelled (nicht gewertet) | 1 sonstige, Zeitraum 2026-08-27T19:01 bis 2026-08-28T18:17 UTC
