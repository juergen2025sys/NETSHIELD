# ✅ OK

0 Rückfälle - keine der 836,011 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-18 01:51 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,414,314)
- seit Zyklus-Start (2026-08-23): 📈 +2,018,275 (Anstieg)
- letzter combined-Cleanup-Pass: 244,132 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,132 Active/180T), 1,069,484 neue IPs hinzugekommen (davon 934,145 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 4 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 Whitelist-Bereinigung, 131,559 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,597,278 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,953,175 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,953,175 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 13/13 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 2 cancelled (nicht gewertet) | 1 sonstige, Zeitraum 2026-09-17T05:34 bis 2026-09-17T23:43 UTC
