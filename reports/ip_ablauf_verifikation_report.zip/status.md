# ✅ OK

0 Rückfälle - keine der 835,466 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-19 13:43 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +9,811 (Anstieg) (jetzt 11,537,242)
- seit Zyklus-Start (2026-08-23): 📈 +2,141,203 (Anstieg)
- letzter combined-Cleanup-Pass: 243,817 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,817 Active/180T), 1,081,005 neue IPs hinzugekommen (davon 937,874 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 804 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 5 Whitelist-Bereinigung, 133,593 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,584,770 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,951,249 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,951,249 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-18T21:04 bis 2026-09-19T11:34 UTC
