# ✅ OK

0 Rückfälle - keine der 836,108 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-17 14:20 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,691 (Anstieg) (jetzt 11,386,652)
- seit Zyklus-Start (2026-08-23): 📈 +1,990,613 (Anstieg)
- letzter combined-Cleanup-Pass: 244,168 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,168 Active/180T), 1,075,854 neue IPs hinzugekommen (davon 935,634 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 427 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 136,811 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,613,480 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,956,236 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,954,236 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-16T17:10 bis 2026-09-17T12:07 UTC
