# ✅ OK

0 Rückfälle - keine der 835,293 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-19 23:12 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,558 (Anstieg) (jetzt 11,563,888)
- seit Zyklus-Start (2026-08-23): 📈 +2,167,849 (Anstieg)
- letzter combined-Cleanup-Pass: 243,618 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,618 Active/180T), 1,070,964 neue IPs hinzugekommen (davon 937,709 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 213 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 129,976 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,622,746 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,950,027 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,950,027 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-19T04:49 bis 2026-09-19T21:03 UTC
