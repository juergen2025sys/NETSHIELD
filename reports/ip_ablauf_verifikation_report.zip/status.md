# ✅ OK

0 Rückfälle - keine der 3,887,917 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-10 08:55 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,287 (Anstieg) (jetzt 11,210,399)
- seit Zyklus-Start (2026-10-22): 📈 +151,956 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 810,795 neue IPs hinzugekommen (davon 708,457 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 51 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,578 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,710,560 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 34,515 | gestern 27,361 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 32,515 | gestern 25,361
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-09T01:03 bis 2026-11-10T07:45 UTC
