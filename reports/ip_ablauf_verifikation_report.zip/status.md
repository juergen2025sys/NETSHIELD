# ✅ OK

0 Rückfälle - keine der 626,983 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-25 21:27 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,033 (Anstieg) (jetzt 8,958,104)
- seit Zyklus-Start (2026-08-23): 📉 -437,935 (Rückgang)
- letzter combined-Cleanup-Pass: 618,701 IPs durch Ablauf entfernt (davon 618,701 Watchlist/30T, 0 Active/180T), 1,865,866 neue IPs hinzugekommen (davon 1,675,345 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 10 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 188,958 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,851,807 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 4,951,270 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,951,270 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-25T07:23 bis 2026-08-25T19:17 UTC
