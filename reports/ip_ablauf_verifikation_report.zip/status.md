# ✅ OK

0 Rückfälle - keine der 1,001,924 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-04 04:01 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -2,738 (Rückgang) (jetzt 12,167,966)
- seit Zyklus-Start (2026-09-22): 📈 +690,247 (Anstieg)
- letzter combined-Cleanup-Pass: 14,536 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 12,536 Active/180T), 908,065 neue IPs hinzugekommen (davon 788,489 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 8 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 112,681 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,269,677 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 14,536 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 12,536 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-03T11:32 bis 2026-10-04T00:32 UTC
