# ✅ OK

0 Rückfälle - keine der 1,020,994 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-10 18:48 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +12,486 (Anstieg) (jetzt 10,879,779)
- seit Zyklus-Start (2026-08-23): 📈 +1,483,740 (Anstieg)
- letzter combined-Cleanup-Pass: 291,371 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 291,371 Active/180T), 1,137,069 neue IPs hinzugekommen (davon 939,440 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 50 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 189,292 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,960,203 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,336,320 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,334,320 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-09T23:08 bis 2026-09-10T16:41 UTC
