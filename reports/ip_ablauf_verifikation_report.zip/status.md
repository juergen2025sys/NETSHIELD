# ✅ OK

0 Rückfälle - keine der 1,020,827 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-11 01:35 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +19,705 (Anstieg) (jetzt 10,906,266)
- seit Zyklus-Start (2026-08-23): 📈 +1,510,227 (Anstieg)
- letzter combined-Cleanup-Pass: 271,883 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 271,883 Active/180T), 1,160,221 neue IPs hinzugekommen (davon 949,234 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 836 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 195,421 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 9,098,874 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,315,037 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,313,037 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-10T11:08 bis 2026-09-10T23:24 UTC
