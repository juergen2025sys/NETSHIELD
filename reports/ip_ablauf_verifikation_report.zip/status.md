# ✅ OK

0 Rückfälle - keine der 840,909 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-22 14:14 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +16,831 (Anstieg) (jetzt 11,512,773)
- seit Zyklus-Start (2026-09-22): 📈 +35,054 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 962,906 neue IPs hinzugekommen (davon 829,178 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 6 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 127,227 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,815,873 (Summe letzte 5 Läufe / 5 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- entfernte IPs (Summe letzter Läufe): 16,860 (Summe letzte 5 Läufe / 5 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 5 Läufe / 5 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Active/180 Tage: 12,860 (Summe letzte 5 Läufe / 5 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-21T19:56 bis 2026-09-22T12:03 UTC
