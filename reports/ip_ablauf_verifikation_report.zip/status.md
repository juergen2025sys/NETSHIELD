# ✅ OK

0 Rückfälle - keine der 3,993,598 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-15 22:01 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,178 (Anstieg) (jetzt 11,359,050)
- seit Zyklus-Start (2026-10-22): 📈 +300,607 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 819,052 neue IPs hinzugekommen (davon 712,969 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 25 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 103,999 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,571,829 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 19,363 | gestern 24,795 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 17,363 | gestern 22,795
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-14T19:59 bis 2026-11-15T19:03 UTC
