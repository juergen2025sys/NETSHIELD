# ✅ OK

0 Rückfälle - keine der 968,998 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-01 21:26 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +7,740 (Anstieg) (jetzt 12,028,855)
- seit Zyklus-Start (2026-09-22): 📈 +551,136 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 915,487 neue IPs hinzugekommen (davon 791,050 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 18 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 119,424 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,379,052 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 18,547 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 16,547 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-01T00:39 bis 2026-10-01T19:05 UTC
