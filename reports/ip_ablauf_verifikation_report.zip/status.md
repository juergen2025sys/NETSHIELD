# ✅ OK

0 Rückfälle - keine der 836,371 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-16 19:24 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +7,570 (Anstieg) (jetzt 11,344,650)
- seit Zyklus-Start (2026-08-23): 📈 +1,948,611 (Anstieg)
- letzter combined-Cleanup-Pass: 244,228 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,228 Active/180T), 1,072,073 neue IPs hinzugekommen (davon 933,450 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 1 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 134,844 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,554,089 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,958,163 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,956,163 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-15T23:44 bis 2026-09-16T17:17 UTC
