# ✅ OK

0 Rückfälle - keine der 3,290,306 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-22 07:38 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +10,176 (Anstieg) (jetzt 11,068,619)
- seit Zyklus-Start (2026-10-22): 📈 +10,176 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 892,557 neue IPs hinzugekommen (davon 762,296 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 2,830 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,407 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 1,783,903 (Summe letzte 2 Läufe / 2 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- entfernte IPs (Summe letzter Läufe): 32,437 (Summe letzte 2 Läufe / 2 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 2 Läufe / 2 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Active/180 Tage: 30,437 (Summe letzte 2 Läufe / 2 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-21T11:37 bis 2026-10-22T05:23 UTC
