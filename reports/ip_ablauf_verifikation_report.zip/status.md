# ✅ OK

0 Rückfälle - keine der 969,406 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-01 12:37 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +17,075 (Anstieg) (jetzt 12,000,275)
- seit Zyklus-Start (2026-09-22): 📈 +522,556 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 924,758 neue IPs hinzugekommen (davon 795,707 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 469 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,999 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,390,858 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 18,547 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 16,547 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-30T20:10 bis 2026-10-01T10:27 UTC
