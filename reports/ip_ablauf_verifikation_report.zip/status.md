# ✅ OK

0 Rückfälle - keine der 3,951,908 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-13 12:46 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +4,653 (Anstieg) (jetzt 11,310,584)
- seit Zyklus-Start (2026-10-22): 📈 +252,141 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 822,946 neue IPs hinzugekommen (davon 711,195 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 43 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,188 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 4,930,398 (Summe 6 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 21,521 | gestern 22,375 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 19,521 | gestern 20,375
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-12T18:40 bis 2026-11-13T11:36 UTC
