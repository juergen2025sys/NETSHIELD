# ✅ OK

0 Rückfälle - keine der 183,204 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-30 01:46 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,312 (Anstieg) (jetzt 9,546,199)
- seit Zyklus-Start (2026-08-23): 📈 +150,160 (Anstieg)
- letzter combined-Cleanup-Pass: 162,252 IPs durch Ablauf entfernt (davon 162,252 Watchlist/30T, 0 Active/180T), 1,858,251 neue IPs hinzugekommen (davon 1,683,926 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 41 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 190,190 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,879,601 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,298,366 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 1,298,366 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-29T09:10 bis 2026-08-29T23:36 UTC
