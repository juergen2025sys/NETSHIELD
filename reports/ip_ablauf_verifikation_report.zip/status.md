# ✅ OK

0 Rückfälle - keine der 1,038,690 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-06 09:03 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +20,462 (Anstieg) (jetzt 12,298,552)
- seit Zyklus-Start (2026-09-22): 📈 +820,833 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 919,277 neue IPs hinzugekommen (davon 793,096 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 6,420 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 118,890 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,263,575 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 18,020 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 16,020 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-05T14:24 bis 2026-10-06T06:52 UTC
