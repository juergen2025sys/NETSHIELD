# ✅ OK

0 Rückfälle - keine der 1,478,728 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-12 08:58 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +10,080 (Anstieg) (jetzt 12,260,598)
- seit Zyklus-Start (2026-09-22): 📈 +782,879 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 900,569 neue IPs hinzugekommen (davon 768,913 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 619 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 121,729 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,179,010 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 136,958 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 132,958 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-11T06:29 bis 2026-10-12T06:35 UTC
