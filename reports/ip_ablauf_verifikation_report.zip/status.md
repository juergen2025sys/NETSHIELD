# ✅ OK

0 Rückfälle - keine der 836,589 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-16 07:32 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +9,284 (Anstieg) (jetzt 11,311,000)
- seit Zyklus-Start (2026-08-23): 📈 +1,914,961 (Anstieg)
- letzter combined-Cleanup-Pass: 244,581 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,581 Active/180T), 1,081,614 neue IPs hinzugekommen (davon 934,902 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 4,085 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 139,717 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,544,905 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,959,114 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,957,114 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-15T11:35 bis 2026-09-16T05:18 UTC
