# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 29403 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-11-04 02:47 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -29,633 (Rückgang) (jetzt 11,158,594)
- seit Zyklus-Start (2026-10-22): 📈 +100,151 (Anstieg)
- letzter combined-Cleanup-Pass: 31,403 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 29,403 Active/180T), 820,558 neue IPs hinzugekommen (davon 700,583 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 74 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 120,341 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,552,695 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 94,521 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 6,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 88,521 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-03T01:05 bis 2026-11-04T01:39 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| blacklist_confidence40_ipv4_part1.txt | 23817 | 1.0.0.229, 1.0.140.160, 1.1.240.52, 1.1.242.196, 1.1.246.141, ... |
| blacklist_confidence40_ipv4_part2.txt | 5586 | 34.150.193.0, 34.158.16.143, 34.162.197.119, 34.162.95.64, 34.169.220.33, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
