# ✅ OK

0 Rückfälle - keine der 1,018,333 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-13 18:45 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,833 (Anstieg) (jetzt 11,098,270)
- seit Zyklus-Start (2026-08-23): 📈 +1,702,231 (Anstieg)
- letzter combined-Cleanup-Pass: 244,860 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,860 Active/180T), 1,071,754 neue IPs hinzugekommen (davon 935,134 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 35 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 geschützt entfernt, 137,880 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,579,612 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,962,282 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,962,282 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-13T01:10 bis 2026-09-13T16:38 UTC
