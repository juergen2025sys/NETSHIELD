# ✅ OK

0 Rückfälle - keine der 3,137,382 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-15 07:25 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 10,793,337)
- seit Zyklus-Start (2026-09-22): 📉 -684,382 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 899,784 neue IPs hinzugekommen (davon 766,424 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 3,201 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 121,466 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,111,482 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 34,900 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 32,900 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-14T09:50 bis 2026-10-15T05:15 UTC
