# ✅ OK

0 Rückfälle - keine der 834,830 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-21 07:43 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +18,057 (Anstieg) (jetzt 11,645,885)
- seit Zyklus-Start (2026-08-23): 📈 +2,249,846 (Anstieg)
- letzter combined-Cleanup-Pass: 243,062 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,062 Active/180T), 1,077,906 neue IPs hinzugekommen (davon 939,213 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 755 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 130,969 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,578,043 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,946,745 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,944,745 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-20T16:20 bis 2026-09-21T05:30 UTC
