# ✅ OK

0 Rückfälle - keine der 3,290,246 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-22 14:40 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +12,313 (Anstieg) (jetzt 11,089,919)
- seit Zyklus-Start (2026-10-22): 📈 +31,476 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 896,407 neue IPs hinzugekommen (davon 762,658 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 250 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 121,756 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 3,572,794 (Summe letzte 4 Läufe / 4 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- entfernte IPs (Summe letzter Läufe): 32,437 (Summe letzte 4 Läufe / 4 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 4 Läufe / 4 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Active/180 Tage: 30,437 (Summe letzte 4 Läufe / 4 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-10-21T17:28 bis 2026-10-22T12:32 UTC
