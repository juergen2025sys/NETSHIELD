# ✅ OK

0 Rückfälle - keine der 834,756 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-21 15:30 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -179,536 (Rückgang) (jetzt 11,466,349)
- seit Zyklus-Start (2026-08-23): 📈 +2,070,310 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 952,807 neue IPs hinzugekommen (davon 825,084 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 8 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 126,631 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,463,229 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,703,570 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,701,570 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 14/14 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet) | 1 sonstige, Zeitraum 2026-09-20T21:39 bis 2026-09-21T13:29 UTC
