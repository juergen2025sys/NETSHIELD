# ✅ OK

0 Rückfälle - keine der 3,887,528 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-11 00:51 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,768 (Anstieg) (jetzt 11,243,443)
- seit Zyklus-Start (2026-10-22): 📈 +185,000 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 811,234 neue IPs hinzugekommen (davon 708,279 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 2 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 107,715 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,694,964 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 0 | gestern 34,513 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 0 | gestern 2,000
  - davon Active/180 Tage: heute 0 | gestern 32,513
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-10T00:28 bis 2026-11-10T23:44 UTC
