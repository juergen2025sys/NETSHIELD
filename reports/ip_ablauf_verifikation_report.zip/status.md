# ✅ OK

0 Rückfälle - keine der 197,953 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-30 12:38 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +366 (Anstieg) (jetzt 9,541,268)
- seit Zyklus-Start (2026-08-23): 📈 +145,229 (Anstieg)
- letzter combined-Cleanup-Pass: 171,825 IPs durch Ablauf entfernt (davon 171,825 Watchlist/30T, 0 Active/180T), 1,858,743 neue IPs hinzugekommen (davon 1,687,820 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 39 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 192,538 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,869,727 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,332,321 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 1,332,321 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-08-29T15:46 bis 2026-08-30T07:13 UTC
