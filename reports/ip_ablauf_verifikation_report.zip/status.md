# ✅ OK

0 Rückfälle - keine der 3,253,412 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-20 07:37 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +14,029 (Anstieg) (jetzt 10,976,043)
- seit Zyklus-Start (2026-09-22): 📉 -501,676 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 897,808 neue IPs hinzugekommen (davon 763,907 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 199 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,192 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,145,191 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 13,053 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 11,053 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-19T06:43 bis 2026-10-20T05:20 UTC
