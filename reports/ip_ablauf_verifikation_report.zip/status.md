# ✅ OK

0 Rückfälle - keine der 4,440,772 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-26 20:01 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +2,377 (Anstieg) (jetzt 11,311,169)
- seit Zyklus-Start (2026-11-21): 📈 +38,959 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 905,280 neue IPs hinzugekommen (davon 801,742 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 95 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 103,987 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,364,301 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 30,507 | gestern 28,315 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 997
  - davon Active/180 Tage: heute 28,507 | gestern 27,318
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-11-25T19:27 bis 2026-11-26T18:56 UTC
