# ✅ OK

0 Rückfälle - keine der 1,021,181 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-10 13:10 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +10,486 (Anstieg) (jetzt 10,860,609)
- seit Zyklus-Start (2026-08-23): 📈 +1,464,570 (Anstieg)
- letzter combined-Cleanup-Pass: 291,591 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 291,591 Active/180T), 1,135,103 neue IPs hinzugekommen (davon 944,325 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 365 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 188,847 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,935,531 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,339,142 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,337,142 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-09T16:48 bis 2026-09-10T11:08 UTC
