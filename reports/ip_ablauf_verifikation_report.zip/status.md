# ✅ OK

0 Rückfälle - keine der 0 eingefrorenen IPs taucht in 0 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-24 00:14 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,405 (Anstieg) (jetzt 9,415,235)
- seit Zyklus-Start (2026-08-23): 📈 +19,196 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 1,861,569 neue IPs hinzugekommen (davon 1,671,401 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 186,763 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): n/a (3/8 Läufe im Fenster mit Daten)
- entfernte IPs (Summe letzter Läufe): n/a (3/8 Läufe im Fenster mit Daten)
  - davon Watchlist/30 Tage: n/a (2/8 Läufe im Fenster mit Daten)
  - davon Active/180 Tage: n/a (2/8 Läufe im Fenster mit Daten)
- Erfolgsquote letzte 16 combined-Läufe: 12/14 erfolgreich (86%, nur echte Erfolge/Fehlschläge gezählt) | 2 sonstige, Zeitraum 2026-08-23T13:20 bis 2026-08-23T21:57 UTC
