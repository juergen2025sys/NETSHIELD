# ✅ OK

0 Rückfälle - keine der 4,026,932 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-17 20:48 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,250 (Anstieg) (jetzt 11,385,629)
- seit Zyklus-Start (2026-10-22): 📈 +327,186 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 828,177 neue IPs hinzugekommen (davon 714,696 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 17 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,233 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,601,400 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 17,141 | gestern 19,004 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,175
  - davon Active/180 Tage: heute 15,141 | gestern 17,829
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-16T16:21 bis 2026-11-17T18:49 UTC
