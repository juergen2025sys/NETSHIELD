# ✅ OK

0 Rückfälle - keine der 3,059,940 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-13 19:09 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +15,398 (Anstieg) (jetzt 10,777,172)
- seit Zyklus-Start (2026-09-22): 📉 -700,547 (Rückgang)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 904,752 neue IPs hinzugekommen (davon 766,724 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 129 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,713 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,154,625 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 3,163,382 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 3,159,382 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-12T10:37 bis 2026-10-13T16:53 UTC
