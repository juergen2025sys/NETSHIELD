# ✅ OK

0 Rückfälle - keine der 0 eingefrorenen IPs taucht in 0 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-23 21:43 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +5,648 (Anstieg) (jetzt 9,411,701)
- seit Zyklus-Start (2026-08-23): 📈 +15,662 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt, 1,863,994 neue IPs hinzugekommen (zusätzlich: 186,911 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): n/a (1/8 Läufe im Fenster mit Daten)
- entfernte IPs (Summe letzter Läufe): n/a (1/8 Läufe im Fenster mit Daten)
  - davon Watchlist/30 Tage: n/a (0/8 Läufe im Fenster mit Daten)
  - davon Active/180 Tage: n/a (0/8 Läufe im Fenster mit Daten)
- Erfolgsquote letzte 16 combined-Läufe: 8/10 erfolgreich (80%, nur echte Erfolge/Fehlschläge gezählt) | 6 sonstige, Zeitraum 2026-08-23T12:40 bis 2026-08-23T19:08 UTC
