# ✅ OK

0 Rückfälle - keine der 1,338,963 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-09 20:36 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +18,095 (Anstieg) (jetzt 12,231,552)
- seit Zyklus-Start (2026-09-22): 📈 +753,833 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 928,375 neue IPs hinzugekommen (davon 789,246 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 17 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 121,335 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,375,940 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 445,250 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 441,250 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-10-08T19:00 bis 2026-10-09T18:31 UTC
