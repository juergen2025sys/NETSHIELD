# ✅ OK

0 Rückfälle - keine der 3,776,429 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-06 19:23 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +8,611 (Anstieg) (jetzt 11,189,196)
- seit Zyklus-Start (2026-10-22): 📈 +130,753 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 814,263 neue IPs hinzugekommen (davon 700,605 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 37 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 12 Whitelist-Bereinigung, 109,074 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,498,377 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 38,119 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 36,119 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-05T16:35 bis 2026-11-06T16:41 UTC
