# ✅ OK

0 Rückfälle - keine der 184,313 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-08-29 04:02 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -175,018 (Rückgang) (jetzt 9,513,964)
- seit Zyklus-Start (2026-08-23): 📈 +117,925 (Anstieg)
- letzter combined-Cleanup-Pass: 184,313 IPs durch Ablauf entfernt (davon 184,313 Watchlist/30T, 0 Active/180T), 1,865,981 neue IPs hinzugekommen (davon 1,666,558 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 67 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 192,804 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
- entfernte IPs (Summe letzter Läufe): n/a (7/8 Läufe im Fenster mit Daten)
  - davon Watchlist/30 Tage: n/a (7/8 Läufe im Fenster mit Daten)
  - davon Active/180 Tage: n/a (7/8 Läufe im Fenster mit Daten)
- Erfolgsquote letzte 16 combined-Läufe: 13/14 erfolgreich (93%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 2 cancelled (nicht gewertet), Zeitraum 2026-08-28T00:36 bis 2026-08-29T01:48 UTC
