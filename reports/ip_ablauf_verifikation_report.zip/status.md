# ✅ OK

0 Rückfälle - keine der 1,019,802 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-12 21:40 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +3,961 (Anstieg) (jetzt 11,061,542)
- seit Zyklus-Start (2026-08-23): 📈 +1,665,503 (Anstieg)
- letzter combined-Cleanup-Pass: 245,453 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 245,453 Active/180T), 1,067,787 neue IPs hinzugekommen (davon 935,222 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 371 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 1 geschützt entfernt, 135,885 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,358,669 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,964,993 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,962,993 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 13/15 erfolgreich (87%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-12T05:06 bis 2026-09-12T19:23 UTC
