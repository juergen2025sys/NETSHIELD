# ❌ ALARM

**2 Problem(e) erkannt:**

- ❌ **Rückfall:** 35410 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.
- ⚠️ **Niedrige combined-Erfolgsquote:** nur 10/15 erfolgreich (67%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-08-24T11:40 bis 2026-08-24T19:53 UTC in den letzten 16 Läufen (Schwelle: 75%, cancelled nicht mitgezaehlt) - auch wenn der neueste Stand frisch wirkt, lief das System zuletzt nicht zuverlässig.

Lauf: 2026-08-24 22:16 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +548 (Anstieg) (jetzt 8,927,370)
- seit Zyklus-Start (2026-08-23): 📉 -468,669 (Rückgang)
- letzter combined-Cleanup-Pass: 616,844 IPs durch Ablauf entfernt (davon 616,844 Watchlist/30T, 0 Active/180T), 1,856,720 neue IPs hinzugekommen (davon 1,671,034 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 187,876 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 14,859,850 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 4,934,862 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,934,862 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 0 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 🔍 10/15 erfolgreich (67%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-08-24T11:40 bis 2026-08-24T19:53 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| active_blacklist_ipv4.txt | 35410 | 1.0.218.230, 1.1.202.148, 1.11.62.185, 1.11.62.186, 1.116.214.66, ... |
| combined_threat_blacklist_ipv4_part1.txt | 12674 | 1.0.218.230, 1.1.202.148, 1.11.62.185, 1.11.62.186, 1.116.214.66, ... |
| combined_threat_blacklist_ipv4_part2.txt | 22736 | 112.252.132.185, 113.100.186.171, 113.105.165.183, 113.106.61.233, 113.108.247.146, ... |
| blacklist_confidence40_ipv4_part1.txt | 35405 | 1.0.218.230, 1.1.202.148, 1.11.62.185, 1.11.62.186, 1.116.214.66, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
