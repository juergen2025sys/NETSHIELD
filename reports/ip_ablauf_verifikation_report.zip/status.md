# ✅ OK

0 Rückfälle - keine der 835,761 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-18 14:00 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +27,374 (Anstieg) (jetzt 11,461,407)
- seit Zyklus-Start (2026-08-23): 📈 +2,065,368 (Anstieg)
- letzter combined-Cleanup-Pass: 243,977 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,977 Active/180T), 1,071,027 neue IPs hinzugekommen (davon 931,995 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 34 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 133,716 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,583,633 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,954,851 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,952,851 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-17T18:26 bis 2026-09-18T11:50 UTC
