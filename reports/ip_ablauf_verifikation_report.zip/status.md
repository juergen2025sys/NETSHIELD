# ✅ OK

0 Rückfälle - keine der 3,801,583 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-07 17:59 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,826 (Anstieg) (jetzt 11,192,145)
- seit Zyklus-Start (2026-10-22): 📈 +133,702 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 810,768 neue IPs hinzugekommen (davon 702,196 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 18 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,739 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,488,045 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 26,295 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 24,295 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-06T15:16 bis 2026-11-07T16:39 UTC
