# ✅ OK

0 Rückfälle - keine der 3,290,334 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-10-22 03:48 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -23,586 (Rückgang) (jetzt 11,058,443)
- seit Zyklus-Start (2026-10-22): n/a (kein Vergleichswert)
- letzter combined-Cleanup-Pass: 32,437 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 30,437 Active/180T), 891,346 neue IPs hinzugekommen (davon 760,354 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 71 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 122,463 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 891,346 (Summe letzte 1 Läufe / 1 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- entfernte IPs (Summe letzter Läufe): 32,437 (Summe letzte 1 Läufe / 1 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 1 Läufe / 1 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
  - davon Active/180 Tage: 30,437 (Summe letzte 1 Läufe / 1 Lauf(e), noch keine 24h Historie seit Zyklus-Start)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-10-21T05:20 bis 2026-10-22T00:43 UTC
