# ✅ OK

0 Rückfälle - keine der 3,910,494 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-11 18:36 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,915 (Anstieg) (jetzt 11,266,952)
- seit Zyklus-Start (2026-10-22): 📈 +208,509 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 821,977 neue IPs hinzugekommen (davon 716,478 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 15 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,231 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,526,314 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 24,183 | gestern 33,666 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,157
  - davon Active/180 Tage: heute 22,183 | gestern 32,509
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-10T17:17 bis 2026-11-11T17:27 UTC
