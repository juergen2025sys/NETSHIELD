# ✅ OK

0 Rückfälle - keine der 1,021,128 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-10 17:10 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,684 (Anstieg) (jetzt 10,867,293)
- seit Zyklus-Start (2026-08-23): 📈 +1,471,254 (Anstieg)
- letzter combined-Cleanup-Pass: 291,386 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 291,386 Active/180T), 1,134,820 neue IPs hinzugekommen (davon 943,283 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 368 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 188,999 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,952,494 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 2,337,319 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 2,335,319 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-09T18:46 bis 2026-09-10T11:50 UTC
