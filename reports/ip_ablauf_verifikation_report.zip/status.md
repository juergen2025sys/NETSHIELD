# ✅ OK

0 Rückfälle - keine der 835,079 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-20 18:39 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,018 (Anstieg) (jetzt 11,612,057)
- seit Zyklus-Start (2026-08-23): 📈 +2,216,018 (Anstieg)
- letzter combined-Cleanup-Pass: 243,133 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,133 Active/180T), 1,071,702 neue IPs hinzugekommen (davon 937,701 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 256 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 128,249 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,610,191 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,947,678 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,947,678 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-19T22:53 bis 2026-09-20T16:29 UTC
