# ✅ OK

0 Rückfälle - keine der 4,244,615 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-20 03:46 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📉 -22,319 (Rückgang) (jetzt 11,242,944)
- seit Zyklus-Start (2026-10-22): 📈 +184,501 (Anstieg)
- letzter combined-Cleanup-Pass: 27,980 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 25,980 Active/180T), 825,931 neue IPs hinzugekommen (davon 710,867 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 81 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 109,939 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,763,919 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 27,980 | gestern 175,100 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 25,980 | gestern 173,100
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-19T03:44 bis 2026-11-20T02:37 UTC
