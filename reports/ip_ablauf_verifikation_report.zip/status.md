# ✅ OK

0 Rückfälle - keine der 835,302 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-19 21:26 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +14,099 (Anstieg) (jetzt 11,560,330)
- seit Zyklus-Start (2026-08-23): 📈 +2,164,291 (Anstieg)
- letzter combined-Cleanup-Pass: 243,618 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,618 Active/180T), 1,079,873 neue IPs hinzugekommen (davon 935,522 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 85 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 130,531 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,623,268 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,950,300 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,950,300 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/16 erfolgreich (94%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-18T23:35 bis 2026-09-19T18:52 UTC
