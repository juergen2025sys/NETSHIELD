# ✅ OK

0 Rückfälle - keine der 835,495 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-19 11:25 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +19,049 (Anstieg) (jetzt 11,527,431)
- seit Zyklus-Start (2026-08-23): 📈 +2,131,392 (Anstieg)
- letzter combined-Cleanup-Pass: 243,850 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,850 Active/180T), 1,085,137 neue IPs hinzugekommen (davon 934,116 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 34 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 132,251 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,568,587 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,951,405 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,951,405 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | zusätzlich 1 cancelled (nicht gewertet), Zeitraum 2026-09-18T16:43 bis 2026-09-19T06:34 UTC
