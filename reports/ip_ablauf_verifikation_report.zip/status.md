# ❌ ALARM

**1 Problem(e) erkannt:**

- ⚠️ **Niedrige combined-Erfolgsquote:** nur 11/15 erfolgreich (73%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-08-23T18:54 bis 2026-08-24T02:11 UTC in den letzten 16 Läufen (Schwelle: 75%, cancelled nicht mitgezaehlt) - auch wenn der neueste Stand frisch wirkt, lief das System zuletzt nicht zuverlässig.

Lauf: 2026-08-24 04:19 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 9,416,186)
- seit Zyklus-Start (2026-08-23): 📈 +20,147 (Anstieg)
- letzter combined-Cleanup-Pass: 657,377 IPs durch Ablauf entfernt (davon 657,377 Watchlist/30T, 0 Active/180T), 1,859,117 neue IPs hinzugekommen (davon 1,670,056 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 186,902 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): n/a (5/8 Läufe im Fenster mit Daten)
- entfernte IPs (Summe letzter Läufe): n/a (5/8 Läufe im Fenster mit Daten)
  - davon Watchlist/30 Tage: n/a (4/8 Läufe im Fenster mit Daten)
  - davon Active/180 Tage: n/a (4/8 Läufe im Fenster mit Daten)
- Erfolgsquote letzte 16 combined-Läufe: 🔍 11/15 erfolgreich (73%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-08-23T18:54 bis 2026-08-24T02:11 UTC

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
