# ✅ OK

0 Rückfälle - keine der 4,244,475 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-20 13:22 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,140 (Anstieg) (jetzt 11,259,220)
- seit Zyklus-Start (2026-10-22): 📈 +200,777 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 829,151 neue IPs hinzugekommen (davon 713,734 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 23 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 109,376 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 6,598,673 (Summe 8 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 27,980 | gestern 175,099 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 25,980 | gestern 173,099
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-19T16:34 bis 2026-11-20T12:11 UTC
