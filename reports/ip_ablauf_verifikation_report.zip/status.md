# ✅ OK

0 Rückfälle - keine der 835,228 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-20 07:34 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,584,609)
- seit Zyklus-Start (2026-08-23): 📈 +2,188,570 (Anstieg)
- letzter combined-Cleanup-Pass: 243,573 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,573 Active/180T), 1,081,120 neue IPs hinzugekommen (davon 939,235 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 5,108 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 133,408 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,614,863 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,949,122 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,949,122 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-19T11:34 bis 2026-09-20T05:25 UTC
