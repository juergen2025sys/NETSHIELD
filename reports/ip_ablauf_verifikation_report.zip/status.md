# ✅ OK

0 Rückfälle - keine der 3,975,370 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-14 23:49 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +1,721 (Anstieg) (jetzt 11,348,990)
- seit Zyklus-Start (2026-10-22): 📈 +290,547 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 819,242 neue IPs hinzugekommen (davon 714,334 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 1 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 104,286 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,752,887 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 24,796 | gestern 20,674 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 1,154
  - davon Active/180 Tage: heute 22,796 | gestern 19,520
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-14T01:49 bis 2026-11-14T22:44 UTC
