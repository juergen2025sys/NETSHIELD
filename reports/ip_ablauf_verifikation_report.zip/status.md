# ✅ OK

0 Rückfälle - keine der 4,386,120 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-24 03:42 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 11,255,087)
- seit Zyklus-Start (2026-11-21): 📉 -17,123 (Rückgang)
- letzter combined-Cleanup-Pass: 28,303 IPs durch Ablauf entfernt (davon 2,000 Watchlist/30T, 26,303 Active/180T), 914,670 neue IPs hinzugekommen (davon 805,668 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 86 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 108,052 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,440,215 (Summe 6 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 28,303 | gestern 27,498 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 26,303 | gestern 25,498
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-23T01:32 bis 2026-11-24T02:35 UTC
