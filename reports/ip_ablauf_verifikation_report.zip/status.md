# ❌ ALARM

**1 Problem(e) erkannt:**

- ❌ **Rückfall:** 447 eingefrorene IP(s) stehen trotzdem in aktuellen Output-Dateien - der Anti-Churn-Fix greift hier NICHT wie erwartet.

Lauf: 2026-09-05 13:04 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +1,655 (Anstieg) (jetzt 11,039,912)
- seit Zyklus-Start (2026-08-23): 📈 +1,643,873 (Anstieg)
- letzter combined-Cleanup-Pass: 155,448 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 155,448 Active/180T), 1,016,725 neue IPs hinzugekommen (davon 832,534 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 10 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 186,856 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,139,803 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 799,458 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 4,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 795,458 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-04T20:41 bis 2026-09-05T10:55 UTC

| Datei | Anzahl Rückfälle | Beispiele |
|---|---:|---|
| active_blacklist_ipv4.txt | 226 | 101.53.250.20, 102.129.153.207, 102.129.56.183, 102.64.41.246, 102.88.111.27, ... |
| combined_threat_blacklist_ipv4_part1.txt | 118 | 101.53.250.20, 102.129.153.207, 102.129.56.183, 102.64.41.246, 102.88.111.27, ... |
| combined_threat_blacklist_ipv4_part2.txt | 329 | 113.161.44.1, 113.23.35.151, 113.57.184.205, 115.186.103.226, 115.241.25.146, ... |
| blacklist_confidence40_ipv4_part1.txt | 226 | 101.53.250.20, 102.129.153.207, 102.129.56.183, 102.64.41.246, 102.88.111.27, ... |

Voller Bericht: `reports/ip_ablauf_verifikation_report.md` bzw. `reports/ip_ablauf_verifikation_report.zip` im Repo.
