# ✅ OK

0 Rückfälle - keine der 1,022,230 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-08 13:55 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: ➡️ unverändert (jetzt 10,746,548)
- seit Zyklus-Start (2026-08-23): 📈 +1,350,509 (Anstieg)
- letzter combined-Cleanup-Pass: 292,560 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 292,560 Active/180T), 1,128,603 neue IPs hinzugekommen (davon 941,085 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 5 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 191,172 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,672,886 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,655,246 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 0 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,655,246 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-07T19:22 bis 2026-09-08T11:52 UTC
