# ✅ OK

0 Rückfälle - keine der 933,903 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-28 21:40 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +10,073 (Anstieg) (jetzt 11,840,960)
- seit Zyklus-Start (2026-09-22): 📈 +363,241 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 919,556 neue IPs hinzugekommen (davon 794,768 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 124,759 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,391,781 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 13,588 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 11,588 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-27T21:38 bis 2026-09-28T18:17 UTC
