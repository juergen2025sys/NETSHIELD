# ✅ OK

0 Rückfälle - keine der 3,887,564 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-11-10 21:29 CET (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +8,668 (Anstieg) (jetzt 11,239,675)
- seit Zyklus-Start (2026-10-22): 📈 +181,232 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 816,026 neue IPs hinzugekommen (davon 708,894 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 31 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 106,993 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 5,701,564 (Summe 7 verschiedene Combined-Läufe in den letzten 8 Prüfläufen / ~24h; vor dem Aufnahme-Filter gezählt)
- entfernte IPs (Summe letzter Läufe): heute 34,513 | gestern 27,357 (Kalendertag, aus Ablauf-Ledgern)
  - davon Watchlist/30 Tage: heute 2,000 | gestern 2,000
  - davon Active/180 Tage: heute 32,513 | gestern 25,357
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-11-09T21:33 bis 2026-11-10T19:37 UTC
