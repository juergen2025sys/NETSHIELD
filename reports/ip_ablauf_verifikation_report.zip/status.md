# ✅ OK

0 Rückfälle - keine der 1,010,757 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-14 15:32 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +14,218 (Anstieg) (jetzt 11,139,256)
- seit Zyklus-Start (2026-08-23): 📈 +1,743,217 (Anstieg)
- letzter combined-Cleanup-Pass: 245,010 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 245,010 Active/180T), 1,074,917 neue IPs hinzugekommen (davon 939,307 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 163 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 136,558 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,608,284 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,962,634 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,960,634 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-13T20:59 bis 2026-09-14T13:21 UTC
