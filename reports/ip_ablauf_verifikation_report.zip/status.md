# ✅ OK

0 Rückfälle - keine der 835,722 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-18 18:45 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +12,470 (Anstieg) (jetzt 11,473,877)
- seit Zyklus-Start (2026-08-23): 📈 +2,077,838 (Anstieg)
- letzter combined-Cleanup-Pass: 243,973 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 243,973 Active/180T), 1,064,822 neue IPs hinzugekommen (davon 931,564 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) (zusätzlich: 131,646 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,566,246 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,954,694 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,952,694 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-18T00:36 bis 2026-09-18T16:43 UTC
