# ✅ OK

0 Rückfälle - keine der 922,640 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-27 08:02 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +6,819 (Anstieg) (jetzt 11,772,586)
- seit Zyklus-Start (2026-09-22): 📈 +294,867 (Anstieg)
- letzter combined-Cleanup-Pass: 0 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 0 Active/180T), 935,837 neue IPs hinzugekommen (davon 809,979 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 731 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 121,165 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 7,490,458 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 16,988 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 14,988 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 16/16 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt), Zeitraum 2026-09-26T16:16 bis 2026-09-27T05:48 UTC
