# ✅ OK

0 Rückfälle - keine der 840,595 eingefrorenen IPs taucht in 6 geprueften Output-Dateien auf. Der Fix hält. Keine Ledger-Überschneidung, keine veralteten Daten.

Lauf: 2026-09-15 23:13 CEST (Europe/Berlin)

**seen_db-Trend:**
- seit letztem Lauf: 📈 +11,863 (Anstieg) (jetzt 11,278,810)
- seit Zyklus-Start (2026-08-23): 📈 +1,882,771 (Anstieg)
- letzter combined-Cleanup-Pass: 244,705 IPs durch Ablauf entfernt (davon 0 Watchlist/30T, 244,705 Active/180T), 1,083,156 neue IPs hinzugekommen (davon 938,152 direkt wieder durch Aufnahme-Filter entfernt: <2 Feeds & kein HQ) | 412 IPs heute per Kreuzbestätigung (2. Feed innerhalb 7 Tage) doch aufgenommen (zusätzlich: 133,432 CIDR-Aggregate)
- neue IPs (Summe letzter Läufe): 8,653,425 (Summe letzte 8 Läufe / ~24h)
- entfernte IPs (Summe letzter Läufe): 1,961,005 (Summe letzte 8 Läufe / ~24h)
  - davon Watchlist/30 Tage: 2,000 (Summe letzte 8 Läufe / ~24h)
  - davon Active/180 Tage: 1,959,005 (Summe letzte 8 Läufe / ~24h)
- Erfolgsquote letzte 16 combined-Läufe: 15/15 erfolgreich (100%, nur echte Erfolge/Fehlschläge gezählt) | 1 sonstige, Zeitraum 2026-09-14T23:54 bis 2026-09-15T21:13 UTC
